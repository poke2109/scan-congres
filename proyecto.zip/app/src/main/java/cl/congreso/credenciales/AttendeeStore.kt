package cl.congreso.credenciales

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Attendee(
    val id: String,
    val name: String,
    val institution: String,
    val status: String = "",
    val ticket: String = "",
) {
    /** Advertencias a mostrar antes de imprimir (inscripción pendiente, virtual…). */
    fun warnings(): List<String> {
        val w = mutableListOf<String>()
        val st = AttendeeStore.fold(status)
        if (st.isNotEmpty() && !st.startsWith("aprob") && !st.startsWith("valid")) w.add("Inscripción ${status.uppercase()}")
        if (AttendeeStore.fold(ticket).contains("virtual")) w.add("Inscripción virtual")
        return w
    }
}

data class ColumnMapping(
    val idCol: Int,
    val nameCol: Int,
    val lastNameCol: Int,      // -1 = ninguna
    val institutionCol: Int,   // -1 = ninguna
    val statusCol: Int = -1,
    val ticketCol: Int = -1,
)

data class PrintRecord(val id: String, val name: String, val institution: String, val time: Long)

class AttendeeStore(private val ctx: Context) {

    private val listFile = File(ctx.filesDir, "inscritos.json")
    private val logFile = File(ctx.filesDir, "impresiones.json")

    var attendees: List<Attendee> = emptyList()
        private set
    var sourceName: String = ""
        private set
    private var index: Map<String, Attendee> = emptyMap()
    private val printLog = mutableListOf<PrintRecord>()

    init {
        loadList()
        loadLog()
    }

    // ---------- Lista ----------

    private fun loadList() {
        if (!listFile.exists()) return
        try {
            val o = JSONObject(listFile.readText())
            sourceName = o.optString("source")
            val arr = o.getJSONArray("items")
            val out = ArrayList<Attendee>(arr.length())
            for (i in 0 until arr.length()) {
                val a = arr.getJSONObject(i)
                out.add(Attendee(a.getString("id"), a.getString("name"), a.optString("inst"), a.optString("st"), a.optString("tk")))
            }
            setList(out)
        } catch (_: Exception) {
        }
    }

    fun replaceList(list: List<Attendee>, source: String) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("inst", it.institution)
                .put("st", it.status).put("tk", it.ticket))
        }
        listFile.writeText(JSONObject().put("source", source).put("items", arr).toString())
        sourceName = source
        setList(list)
    }

    private fun setList(list: List<Attendee>) {
        attendees = list
        val m = HashMap<String, Attendee>()
        list.forEach { a -> normId(a.id).takeIf { it.isNotEmpty() }?.let { m.putIfAbsent(it, a) } }
        index = m
    }

    /** Busca al asistente a partir del contenido completo del QR. */
    fun findByQr(raw: String): Attendee? {
        for (c in qrCandidates(raw)) {
            index[normId(c)]?.let { return it }
        }
        return null
    }

    fun search(query: String): List<Attendee> {
        val q = fold(query)
        if (q.isBlank()) return attendees.sortedBy { fold(it.name) }
        val words = q.split(' ').filter { it.isNotBlank() }
        return attendees.filter { a ->
            val hay = fold(a.name + " " + a.institution + " " + a.id)
            words.all { hay.contains(it) }
        }.sortedBy { fold(it.name) }
    }

    // ---------- Registro de impresiones ----------

    private fun loadLog() {
        if (!logFile.exists()) return
        try {
            val arr = JSONArray(logFile.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                printLog.add(PrintRecord(o.getString("id"), o.optString("name"), o.optString("inst"), o.getLong("t")))
            }
        } catch (_: Exception) {
        }
    }

    private fun saveLog() {
        val arr = JSONArray()
        printLog.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("inst", it.institution).put("t", it.time))
        }
        logFile.writeText(arr.toString())
    }

    fun markPrinted(a: Attendee) {
        printLog.add(PrintRecord(a.id, a.name, a.institution, System.currentTimeMillis()))
        saveLog()
    }

    fun printHistory(a: Attendee): List<PrintRecord> =
        if (a.id.isBlank() || a.id == MANUAL_ID) emptyList()
        else printLog.filter { normId(it.id) == normId(a.id) }

    fun uniquePrinted(): Int = printLog.filter { it.id != MANUAL_ID }.map { normId(it.id) }.toSet().size
    fun totalPrints(): Int = printLog.size

    fun clearLog() {
        printLog.clear()
        saveLog()
    }

    fun exportLogCsv(): String {
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val sb = StringBuilder("﻿pedido;nombre;institucion;fecha_hora\n")
        printLog.forEach {
            sb.append(csv(it.id)).append(';').append(csv(it.name)).append(';')
                .append(csv(it.institution)).append(';').append(fmt.format(Date(it.time))).append('\n')
        }
        return sb.toString()
    }

    private fun csv(s: String) = "\"" + s.replace("\"", "\"\"") + "\""

    companion object {
        const val MANUAL_ID = "manual"

        fun normId(s: String): String {
            var t = s.trim().lowercase(Locale.ROOT).removePrefix("#").trim()
            if (t.endsWith(".0")) t = t.dropLast(2)
            // quita ceros a la izquierda en IDs numéricos
            if (t.isNotEmpty() && t.all { it.isDigit() }) t = t.trimStart('0').ifEmpty { "0" }
            return t
        }

        /** Posibles identificadores contenidos en el QR, del más al menos específico. */
        fun qrCandidates(raw: String): List<String> {
            val s = raw.trim()
            val out = LinkedHashSet<String>()
            out.add(s)
            val afterScan = s.substringAfter("/scan/", "")
            val token = (afterScan.ifEmpty { s.substringAfterLast('/') })
                .substringBefore('?').substringBefore('#').trim('/')
            if (token.isNotEmpty()) {
                out.add(token)
                token.split('-', '_', '.').filter { it.isNotBlank() }.forEach { out.add(it) }
            }
            // parámetros tipo ?order=5417 o ?id=5417
            Regex("[?&](?:order|pedido|id|ticket)=([^&#]+)", RegexOption.IGNORE_CASE)
                .findAll(s).forEach { out.add(it.groupValues[1]) }
            return out.toList()
        }

        fun fold(s: String): String =
            Normalizer.normalize(s, Normalizer.Form.NFD)
                .replace(Regex("\\p{M}+"), "")
                .lowercase(Locale.ROOT)
                .replace(Regex("\\s+"), " ")
                .trim()

        // ---------- Construcción de la lista desde la planilla ----------

        fun guessMapping(header: List<String>): ColumnMapping {
            val h = header.map { fold(it) }
            fun find(vararg patterns: String, exclude: List<String> = emptyList()): Int {
                for (p in patterns) {
                    val r = Regex(p)
                    val i = h.indexOfFirst { col -> r.containsMatchIn(col) && exclude.none { col.contains(it) } }
                    if (i >= 0) return i
                }
                return -1
            }
            val id = find(
                "pedido", "order", "orden", "^id$", "folio", "ticket", "inscripcion", "entrada",
                "^n[°º]", "numero", "^id", "codigo",
            ).let { if (it < 0) 0 else it }
            val last = find("apellido", "last ?name", "surname")
            val name = find(
                "nombre completo", "full ?name", "^nombres?$", "first ?name", "nombre", "name",
                exclude = listOf("apellido", "last", "instituc", "empresa", "company", "evento", "event", "producto", "product", "usuario", "user"),
            )
            val inst = find(
                "instituc", "organizac", "empresa", "company", "entidad", "afiliac",
                "universidad", "lugar de trabajo", "organization",
            )
            val status = find("estado valid", "validac", "^estado$", "status")
            val ticket = find("^ticket", "tipo de entrada", "tipo de inscrip", "modalidad", "producto", "product")
            return ColumnMapping(id, if (name < 0) (if (header.size > 1) 1 else 0) else name, last, inst, status, ticket)
        }

        fun buildAttendees(rows: List<List<String>>, m: ColumnMapping): List<Attendee> =
            rows.mapNotNull { r ->
                val id = r.getOrElse(m.idCol) { "" }.trim()
                var name = r.getOrElse(m.nameCol) { "" }.trim()
                if (m.lastNameCol >= 0 && m.lastNameCol != m.nameCol) {
                    val last = r.getOrElse(m.lastNameCol) { "" }.trim()
                    if (last.isNotEmpty() && !fold(name).contains(fold(last))) name = "$name $last".trim()
                }
                fun col(i: Int) = if (i >= 0) clean(r.getOrElse(i) { "" }) else ""
                val inst = col(m.institutionCol)
                if (id.isEmpty() && name.isEmpty()) null
                else Attendee(id, prettyName(name), inst, col(m.statusCol), col(m.ticketCol))
            }

        /** Limpia valores vacíos típicos de las exportaciones (N/A, -, etc.). */
        fun clean(s: String): String {
            val t = s.replace(Regex("\\s+"), " ").trim()
            return if (fold(t) in setOf("n/a", "na", "-", "--", "no aplica", "null", "none", "sin informacion")) "" else t
        }

        private val lowerWords = setOf("de", "del", "la", "las", "los", "y", "e", "da", "do", "dos", "van", "von")

        /** Corrige palabras escritas enteras en mayúsculas o minúsculas ("karina ROBLES" → "Karina Robles"). */
        fun prettyName(s: String): String {
            val es = Locale("es")
            val t = s.replace(Regex("\\s+"), " ").trim()
            return t.split(' ').mapIndexed { i, w ->
                val letters = w.filter { it.isLetter() }
                val uniform = letters.isNotEmpty() && (letters.all { it.isUpperCase() } || letters.all { it.isLowerCase() })
                when {
                    !uniform -> w
                    i > 0 && w.lowercase(es) in lowerWords -> w.lowercase(es)
                    else -> w.lowercase(es).split('-').joinToString("-") { p -> p.replaceFirstChar { it.titlecase(es) } }
                }
            }.joinToString(" ")
        }
    }
}
