package cl.congreso.credenciales

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils

data class LabelConfig(
    val widthMm: Float = 70f,
    val heightMm: Float = 50f,
    val rotation: Int = 90,          // 0, 90, 180, 270
    val header: String = "",
    val showId: Boolean = false,
    val frame: Boolean = false,
)

/**
 * Dibuja la etiqueta en la orientación de lectura y luego la gira
 * para que calce con el ancho del cabezal (384 puntos = 48 mm a 203 dpi).
 */
object LabelRenderer {

    const val PRINTER_DOTS = 384
    const val DOTS_PER_MM = 8f

    /** Imagen en orientación de lectura (para vista previa). */
    fun renderReading(a: Attendee, cfg: LabelConfig): Bitmap {
        val rotated = cfg.rotation == 90 || cfg.rotation == 270
        // Largo de la etiqueta en el sentido de avance del papel
        val feedMm = if (rotated) cfg.widthMm else cfg.heightMm
        val feedDots = (feedMm * DOTS_PER_MM).toInt().coerceAtLeast(80)
        val w = if (rotated) feedDots else PRINTER_DOTS
        val h = if (rotated) PRINTER_DOTS else feedDots

        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.WHITE)

        if (cfg.frame) {
            val p = Paint().apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 3f }
            c.drawRect(1.5f, 1.5f, w - 1.5f, h - 1.5f, p)
        }

        val margin = (3 * DOTS_PER_MM).toInt()   // 3 mm
        val boxW = w - 2 * margin
        val boxH = h - 2 * margin

        val headerLayout = if (cfg.header.isNotBlank())
            fit(cfg.header, boxW, bold = false, start = 24f, min = 16f, maxLines = 2) else null
        val idLayout = if (cfg.showId && a.id.isNotBlank() && a.id != AttendeeStore.MANUAL_ID)
            fit("N° ${a.id}", boxW, bold = false, start = 20f, min = 16f, maxLines = 1) else null

        val reserved = (headerLayout?.height?.plus(14) ?: 0) + (idLayout?.height?.plus(10) ?: 0)
        val available = boxH - reserved

        // Nombre e institución: se reduce el tamaño hasta que ambos quepan
        var nameStart = 64f
        var instStart = 34f
        fun nameLayout() = fit(a.name.ifBlank { " " }, boxW, bold = true, start = nameStart, min = 26f, maxLines = 2)
        fun instLayout() = if (a.institution.isNotBlank())
            fit(a.institution, boxW, bold = false, start = instStart, min = 18f, maxLines = 3) else null
        var nameL: StaticLayout = nameLayout()
        var instL: StaticLayout? = instLayout()
        while (nameL.height + (instL?.height?.plus(18) ?: 0) > available && !(nameStart <= 26f && instStart <= 18f)) {
            nameStart = (nameStart - 3f).coerceAtLeast(26f)
            instStart = (instStart - 2f).coerceAtLeast(18f)
            nameL = nameLayout()
            instL = instLayout()
        }

        val blockH = nameL.height + (instL?.height?.plus(18) ?: 0)
        var y = margin.toFloat()

        headerLayout?.let {
            draw(c, it, margin.toFloat(), y)
            y += it.height + 6
            val p = Paint().apply { color = Color.BLACK; strokeWidth = 2f }
            c.drawLine(margin.toFloat(), y, (w - margin).toFloat(), y, p)
            y += 8
        }

        val bottomLimit = h - margin - (idLayout?.height?.plus(10) ?: 0)
        val top = y + ((bottomLimit - y - blockH) / 2f).coerceAtLeast(0f)
        draw(c, nameL, margin.toFloat(), top)
        instL?.let { draw(c, it, margin.toFloat(), top + nameL.height + 18) }

        idLayout?.let { draw(c, it, margin.toFloat(), (h - margin - it.height).toFloat()) }

        return bmp
    }

    /** Imagen lista para enviar a la impresora (384 puntos de ancho). */
    fun renderForPrinter(a: Attendee, cfg: LabelConfig): Bitmap {
        val reading = renderReading(a, cfg)
        if (cfg.rotation == 0) return reading
        val m = Matrix().apply { postRotate(cfg.rotation.toFloat()) }
        return Bitmap.createBitmap(reading, 0, 0, reading.width, reading.height, m, true)
    }

    private fun paint(bold: Boolean, size: Float) = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        textSize = size
        typeface = Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
    }

    private fun layout(text: String, width: Int, p: TextPaint, maxLines: Int): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, p, width)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setLineSpacing(0f, 1.0f)
            .setIncludePad(false)
            .setMaxLines(maxLines)
            .setEllipsize(TextUtils.TruncateAt.END)
            .build()

    /** Busca el mayor tamaño de letra con el que el texto cabe sin cortar palabras. */
    private fun fit(text: String, width: Int, bold: Boolean, start: Float, min: Float, maxLines: Int): StaticLayout {
        var size = start
        while (size > min) {
            val p = paint(bold, size)
            val l = layout(text, width, p, Int.MAX_VALUE)
            val wordsFit = text.split(Regex("\\s+")).all { p.measureText(it) <= width }
            if (l.lineCount <= maxLines && wordsFit) return layout(text, width, p, maxLines)
            size -= 2f
        }
        return layout(text, width, paint(bold, min), maxLines)
    }

    private fun draw(c: Canvas, l: StaticLayout, x: Float, y: Float) {
        c.save()
        c.translate(x, y)
        l.draw(c)
        c.restore()
    }

    /** Convierte a filas de 48 bytes (1 bit por punto, 1 = negro). */
    fun toRows(bmp: Bitmap, reverseBits: Boolean): List<ByteArray> {
        val w = bmp.width
        val h = bmp.height
        val pixels = IntArray(w * h)
        bmp.getPixels(pixels, 0, w, 0, 0, w, h)
        val bytesPerRow = PRINTER_DOTS / 8
        val xOffset = ((PRINTER_DOTS - w) / 2).coerceAtLeast(0)
        val rows = ArrayList<ByteArray>(h)
        for (y in 0 until h) {
            val row = ByteArray(bytesPerRow)
            for (x in 0 until minOf(w, PRINTER_DOTS)) {
                val px = pixels[y * w + x]
                val lum = (Color.red(px) * 299 + Color.green(px) * 587 + Color.blue(px) * 114) / 1000
                val alpha = Color.alpha(px)
                if (alpha > 128 && lum < 140) {
                    val dx = x + xOffset
                    val bit = if (reverseBits) 7 - (dx % 8) else dx % 8
                    row[dx / 8] = (row[dx / 8].toInt() or (1 shl bit)).toByte()
                }
            }
            rows.add(row)
        }
        return rows
    }
}
