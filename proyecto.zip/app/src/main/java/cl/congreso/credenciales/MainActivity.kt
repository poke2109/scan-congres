package cl.congreso.credenciales

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.preference.PreferenceManager
import cl.congreso.credenciales.databinding.ActivityMainBinding
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@SuppressLint("MissingPermission", "SetTextI18n")
class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var prefs: SharedPreferences
    private lateinit var store: AttendeeStore
    private lateinit var printer: PrinterManager
    private lateinit var sync: SyncManager

    private data class PrintInfo(val device: String, val time: Long)

    private var current: Attendee? = null
    private var printing = false
    private var afterPermissions: (() -> Unit)? = null

    // ---------------- Lanzadores ----------------

    private val scanLauncher = registerForActivityResult(ScanContract()) { r ->
        val text = r.contents
        if (text != null) onScanned(text)
    }

    private val openListLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importList(uri)
    }

    private val exportLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) {
            try {
                contentResolver.openOutputStream(uri)?.use { it.write(store.exportLogCsv().toByteArray()) }
                toast("Registro exportado")
            } catch (e: Exception) {
                toast("No se pudo exportar: ${e.message}")
            }
        }
    }

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res.values.all { it }) {
            afterPermissions?.invoke()
        } else {
            toast("Se necesitan los permisos de Bluetooth para usar la impresora")
        }
        afterPermissions = null
    }

    private val enableBtLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        afterPermissions?.invoke()
        afterPermissions = null
    }

    // ---------------- Ciclo de vida ----------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        prefs = PreferenceManager.getDefaultSharedPreferences(this)
        store = AttendeeStore(this)
        printer = PrinterManager(applicationContext)
        sync = SyncManager(applicationContext, prefs)
        printer.onStateChanged = { _, _ -> runOnUiThread { updatePrinterUi() } }

        b.btnLoadList.setOnClickListener { openListLauncher.launch(arrayOf("*/*")) }
        b.btnConnect.setOnClickListener { onConnectClicked() }
        b.btnScan.setOnClickListener { startScan() }
        b.btnSearch.setOnClickListener { showSearchDialog() }
        b.btnPrint.setOnClickListener { current?.let { confirmAndPrint(it, fromScan = false) } }
        b.btnEdit.setOnClickListener { current?.let { showEditDialog(it) } }

        b.swAutoPrint.isChecked = prefs.getBoolean("auto_print", true)
        b.swContinuous.isChecked = prefs.getBoolean("continuous", false)
        b.swAutoPrint.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("auto_print", v).apply() }
        b.swContinuous.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("continuous", v).apply() }

        updateListUi()
        updatePrinterUi()
        updateCounter()
        startSyncLoop()

        // Reconexión automática a la última impresora usada
        if (savedPrinterAddress() != null && hasBtPermissions() && btAdapter()?.isEnabled == true) {
            connectSaved(silent = true)
        }
    }

    override fun onResume() {
        super.onResume()
        current?.let { showAttendee(it, statusOverride = null) }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) printer.disconnect()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu_settings -> startActivity(Intent(this, SettingsActivity::class.java))
            R.id.menu_test -> {
                val a = Attendee(AttendeeStore.MANUAL_ID, "María José Fernández Villarroel", "Hospital Santiago Oriente Dr. Luis Tisné Brousse")
                showAttendee(a, statusOverride = "Etiqueta de prueba" to COLOR_INFO)
                printAttendee(a, markAsPrinted = false)
            }
            R.id.menu_manual -> showEditDialog(Attendee(AttendeeStore.MANUAL_ID, "", ""))
            R.id.menu_export -> exportLauncher.launch("impresiones_congreso.csv")
            R.id.menu_reset -> AlertDialog.Builder(this)
                .setTitle("Borrar registro")
                .setMessage("Se borrará el registro de etiquetas impresas (${store.totalPrints()}). La lista de inscritos se mantiene.")
                .setPositiveButton("Borrar") { _, _ -> store.clearLog(); updateCounter(); toast("Registro borrado") }
                .setNegativeButton("Cancelar", null)
                .show()
            R.id.menu_diag -> {
                val tv = TextView(this).apply {
                    text = printer.diagnostics(); setTextIsSelectable(true); textSize = 12f
                    typeface = android.graphics.Typeface.MONOSPACE; setPadding(dp(16), dp(8), dp(16), 0)
                }
                AlertDialog.Builder(this).setTitle("Diagnóstico de impresora")
                    .setView(android.widget.ScrollView(this).apply { addView(tv) })
                    .setPositiveButton("Cerrar", null).show()
            }
            R.id.menu_forget -> {
                prefs.edit().remove("printer_address").remove("printer_name").apply()
                printer.disconnect()
                toast("Impresora olvidada")
            }
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    // ---------------- Lista de inscritos ----------------

    private fun importList(uri: Uri) {
        lifecycleScope.launch {
            try {
                val name = fileName(uri)
                val rows = withContext(Dispatchers.IO) {
                    val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                    TableReader.read(bytes, name)
                }
                if (rows.size < 2) {
                    toast("El archivo no tiene filas de datos")
                    return@launch
                }
                showMappingDialog(rows.first(), rows.drop(1), name)
            } catch (e: Exception) {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("No se pudo leer el archivo")
                    .setMessage("Use un archivo CSV o Excel (.xlsx).\n\nDetalle: ${e.message}")
                    .setPositiveButton("OK", null).show()
            }
        }
    }

    private fun fileName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0) ?: "lista"
        }
        return uri.lastPathSegment ?: "lista"
    }

    private fun showMappingDialog(header: List<String>, data: List<List<String>>, source: String) {
        val guess = AttendeeStore.guessMapping(header)
        val cols = header.mapIndexed { i, h -> h.ifBlank { "Columna ${i + 1}" } }
        val withNone = listOf("(ninguna)") + cols
        val pad = dp(20)

        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, dp(8), pad, 0) }
        fun addSpinner(label: String, options: List<String>, selected: Int): Spinner {
            box.addView(TextView(this).apply { text = label; setPadding(0, dp(10), 0, 0); textSize = 13f })
            val sp = Spinner(this)
            sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
            sp.setSelection(selected.coerceIn(0, options.size - 1))
            box.addView(sp)
            return sp
        }
        val spId = addSpinner("Número de pedido (el que viene en el QR)", cols, guess.idCol)
        val spName = addSpinner("Nombre", cols, guess.nameCol)
        val spLast = addSpinner("Apellido (si viene en otra columna)", withNone, guess.lastNameCol + 1)
        val spInst = addSpinner("Institución", withNone, guess.institutionCol + 1)
        val preview = TextView(this).apply { setPadding(0, dp(14), 0, 0); textSize = 14f; setTextColor(Color.DKGRAY) }
        box.addView(preview)

        fun mapping() = ColumnMapping(
            spId.selectedItemPosition, spName.selectedItemPosition,
            spLast.selectedItemPosition - 1, spInst.selectedItemPosition - 1,
            guess.statusCol, guess.ticketCol,
        )
        fun refresh() {
            val sample = AttendeeStore.buildAttendees(data.take(3), mapping())
            preview.text = "Ejemplo:\n" + sample.joinToString("\n") { "• ${it.id}: ${it.name} · ${it.institution.ifBlank { "(sin institución)" }}" }
        }
        val listener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = refresh()
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        listOf(spId, spName, spLast, spInst).forEach { it.onItemSelectedListener = listener }
        refresh()

        AlertDialog.Builder(this)
            .setTitle("Columnas de $source")
            .setView(android.widget.ScrollView(this).apply { addView(box) })
            .setPositiveButton("Cargar ${data.size} filas") { _, _ ->
                val list = AttendeeStore.buildAttendees(data, mapping())
                store.replaceList(list, source)
                updateListUi()
                toast("${list.size} inscritos cargados")
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun updateListUi() {
        val n = store.attendees.size
        b.txtList.text = if (n == 0) "Sin lista de inscritos" else "$n inscritos\n${store.sourceName}"
        b.btnLoadList.text = if (n == 0) "Cargar lista" else "Cambiar"
    }

    private fun updateCounter() {
        val local = "Este teléfono: ${store.uniquePrinted()} personas (${store.totalPrints()} impresiones)"
        if (!sync.enabled) {
            b.txtCounter.text = "$local\nSincronización desactivada (Ajustes)"
            return
        }
        val pend = sync.pendingCount()
        val state = when {
            sync.lastOk == 0L && sync.lastError != null -> "⚠ sin conexión con la planilla: ${sync.lastError}"
            sync.lastOk == 0L -> "conectando con la planilla…"
            System.currentTimeMillis() - sync.lastOk > 60_000 -> "⚠ sin conexión desde las ${time(sync.lastOk)}"
            else -> "✓ sincronizado ${time(sync.lastOk)}"
        }
        b.txtCounter.text = "Todos los teléfonos: ${sync.remoteUniqueCount()} personas\n$local\n" +
            "\"${sync.deviceName}\" · $state" + (if (pend > 0) " · $pend por subir" else "")
    }

    private fun startSyncLoop() {
        lifecycleScope.launch {
            while (true) {
                if (sync.enabled) {
                    sync.flush()
                    sync.refresh()
                    updateCounter()
                }
                delay(15_000)
            }
        }
    }

    /** Impresiones de este teléfono y de los demás (vía planilla), sin duplicados. */
    private fun printsFor(a: Attendee): List<PrintInfo> {
        val out = LinkedHashMap<Long, PrintInfo>()
        store.printHistory(a).forEach { out[it.time] = PrintInfo(sync.deviceName, it.time) }
        if (a.id != AttendeeStore.MANUAL_ID) sync.recordsFor(a.id).forEach { out.putIfAbsent(it.time, PrintInfo(it.device, it.time)) }
        return out.values.sortedBy { it.time }
    }

    private fun describe(p: PrintInfo) =
        time(p.time) + (if (p.device.isNotBlank() && p.device != sync.deviceName) " en ${p.device}" else "")

    // ---------------- Escaneo y búsqueda ----------------

    private fun startScan() {
        if (store.attendees.isEmpty()) toast("Aún no hay lista de inscritos cargada")
        val o = ScanOptions()
            .setDesiredBarcodeFormats(ScanOptions.QR_CODE)
            .setPrompt("Apunte al código QR de la entrada")
            .setBeepEnabled(true)
            .setOrientationLocked(true)
            .setCaptureActivity(PortraitCaptureActivity::class.java)
        scanLauncher.launch(o)
    }

    private fun onScanned(raw: String) {
        if (raw.trim().startsWith("https://script.google.com/")) {
            configureSync(raw.trim())
            return
        }
        val a = store.findByQr(raw)
        if (a == null) {
            current = null
            b.cardResult.visibility = View.VISIBLE
            setStatus("No encontrado en la lista", COLOR_ERROR)
            b.txtName.text = "QR no reconocido"
            b.txtInstitution.text = raw
            b.txtId.text = ""
            b.imgPreview.setImageDrawable(null)
            b.btnPrint.isEnabled = false
            b.btnEdit.isEnabled = false
            AlertDialog.Builder(this)
                .setTitle("No encontrado")
                .setMessage("El código no coincide con ningún pedido de la lista.\n\n$raw")
                .setPositiveButton("Buscar por nombre") { _, _ -> showSearchDialog() }
                .setNeutralButton("Ingresar a mano") { _, _ -> showEditDialog(Attendee(AttendeeStore.MANUAL_ID, "", "")) }
                .setNegativeButton("Cerrar", null)
                .show()
            return
        }
        if (sync.enabled) {
            // Consulta la planilla antes de decidir si imprimir
            current = a
            showAttendee(a, statusOverride = "Verificando en la planilla…" to COLOR_INFO)
            lifecycleScope.launch {
                sync.refresh(timeoutMs = 4000)
                updateCounter()
                select(a, fromScan = true)
            }
        } else {
            select(a, fromScan = true)
        }
    }

    private fun configureSync(url: String) {
        val input = EditText(this).apply {
            hint = "Nombre de este teléfono (ej.: Mesa 1)"
            setText(prefs.getString("device_name", "") ?: "")
            isSingleLine = true
        }
        val box = LinearLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(input, LinearLayout.LayoutParams(-1, -2)) }
        AlertDialog.Builder(this)
            .setTitle("Sincronizar con planilla")
            .setMessage("Este código configura la planilla compartida entre teléfonos.")
            .setView(box)
            .setPositiveButton("Activar") { _, _ ->
                prefs.edit().putString("sync_url", url).putString("device_name", input.text.toString().trim()).apply()
                toast("Sincronización activada")
                lifecycleScope.launch {
                    val ok = sync.refresh()
                    updateCounter()
                    if (!ok) toast("No se pudo conectar con la planilla: ${sync.lastError}")
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun select(a: Attendee, fromScan: Boolean) {
        current = a
        showAttendee(a, statusOverride = null)
        val history = printsFor(a)
        val warnings = a.warnings()
        if (b.swAutoPrint.isChecked && history.isEmpty() && warnings.isEmpty()) {
            printAttendee(a, markAsPrinted = true)
        } else if (b.swAutoPrint.isChecked && fromScan) {
            confirmAndPrint(a, fromScan = true)
        }
    }

    private fun confirmAndPrint(a: Attendee, fromScan: Boolean) {
        val history = printsFor(a)
        val msgs = mutableListOf<String>()
        a.warnings().forEach { msgs.add("• $it") }
        if (history.isNotEmpty()) msgs.add("• Ya se imprimió ${history.size} ${if (history.size == 1) "vez" else "veces"} (última: ${describe(history.last())})")
        if (msgs.isEmpty()) {
            printAttendee(a, markAsPrinted = true)
            return
        }
        AlertDialog.Builder(this)
            .setTitle(a.name)
            .setMessage(msgs.joinToString("\n") + "\n\n¿Imprimir de todas formas?")
            .setPositiveButton("Imprimir") { _, _ -> printAttendee(a, markAsPrinted = true) }
            .setNegativeButton("No imprimir") { _, _ -> if (fromScan && b.swContinuous.isChecked) startScan() }
            .show()
    }

    private fun showAttendee(a: Attendee, statusOverride: Pair<String, Int>?) {
        b.cardResult.visibility = View.VISIBLE
        b.txtName.text = a.name
        b.txtInstitution.text = a.institution.ifBlank { "(sin institución)" }
        b.txtId.text = listOf(
            if (a.id != AttendeeStore.MANUAL_ID) "Pedido ${a.id}" else "Ingreso manual",
            a.ticket,
        ).filter { it.isNotBlank() }.joinToString(" · ")
        b.btnPrint.isEnabled = !printing
        b.btnEdit.isEnabled = true
        b.imgPreview.setImageBitmap(LabelRenderer.renderReading(a, labelConfig()))

        if (statusOverride != null) {
            setStatus(statusOverride.first, statusOverride.second)
            return
        }
        val history = printsFor(a)
        val warnings = a.warnings()
        when {
            warnings.isNotEmpty() -> setStatus("⚠ " + warnings.joinToString(" · ") +
                (if (history.isNotEmpty()) " · ya impresa ${describe(history.last())}" else ""), COLOR_WARN)
            history.isNotEmpty() -> setStatus("Ya impresa (${describe(history.last())})", COLOR_WARN)
            else -> setStatus("Inscripción encontrada", COLOR_OK)
        }
    }

    private fun setStatus(text: String, color: Int) {
        b.txtStatus.text = text
        b.txtStatus.setBackgroundColor(color)
    }

    private fun showSearchDialog() {
        if (store.attendees.isEmpty()) {
            toast("Primero cargue la lista de inscritos")
            return
        }
        val pad = dp(16)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, dp(8), pad, 0) }
        val input = EditText(this).apply { hint = "Nombre, institución o N° de pedido"; isSingleLine = true }
        val list = ListView(this)
        box.addView(input)
        box.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(380)))

        var results = store.search("")
        fun refresh(q: String) {
            results = store.search(q).take(200)
        }
        list.adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_2, android.R.id.text1, mutableListOf()) {
            override fun getCount() = results.size
            override fun getItem(position: Int) = results[position].name
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = convertView ?: layoutInflater.inflate(android.R.layout.simple_list_item_2, parent, false)
                val a = results[position]
                v.findViewById<TextView>(android.R.id.text1).text = a.name
                v.findViewById<TextView>(android.R.id.text2).text =
                    listOf(a.institution, "Pedido ${a.id}").filter { it.isNotBlank() }.joinToString(" · ") +
                        (if (printsFor(a).isNotEmpty()) "  ✓ impresa" else "")
                return v
            }
        }
        refresh("")

        val dialog = AlertDialog.Builder(this)
            .setTitle("Buscar inscrito")
            .setView(box)
            .setNegativeButton("Cerrar", null)
            .create()
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, bf: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                refresh(s?.toString() ?: "")
                (list.adapter as ArrayAdapter<*>).notifyDataSetChanged()
            }
        })
        list.setOnItemClickListener { _, _, pos, _ ->
            val a = results[pos]
            dialog.dismiss()
            current = a
            showAttendee(a, statusOverride = null)
        }
        dialog.show()
    }

    private fun showEditDialog(a: Attendee) {
        val pad = dp(20)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, dp(8), pad, 0) }
        val name = EditText(this).apply {
            hint = "Nombre"; setText(a.name)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
        }
        val inst = EditText(this).apply {
            hint = "Institución"; setText(a.institution)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        box.addView(name)
        box.addView(inst)
        AlertDialog.Builder(this)
            .setTitle(if (a.id == AttendeeStore.MANUAL_ID && a.name.isBlank()) "Ingresar datos" else "Editar etiqueta")
            .setView(box)
            .setPositiveButton("Aceptar") { _, _ ->
                val edited = a.copy(name = name.text.toString().trim(), institution = inst.text.toString().trim())
                current = edited
                showAttendee(edited, statusOverride = null)
            }
            .setNeutralButton("Aceptar e imprimir") { _, _ ->
                val edited = a.copy(name = name.text.toString().trim(), institution = inst.text.toString().trim())
                current = edited
                showAttendee(edited, statusOverride = null)
                printAttendee(edited, markAsPrinted = true)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ---------------- Impresión ----------------

    private fun labelConfig() = LabelConfig(
        widthMm = num("label_width_mm", 70f),
        heightMm = num("label_height_mm", 50f),
        rotation = prefs.getString("rotation", "90")?.toIntOrNull() ?: 90,
        header = prefs.getString("header_text", "") ?: "",
        showId = prefs.getBoolean("show_id", false),
        frame = prefs.getBoolean("frame", false),
        headDots = prefs.getString("head_dots", "384")?.toIntOrNull() ?: 384,
    )

    private fun num(key: String, def: Float): Float =
        prefs.getString(key, null)?.replace(',', '.')?.toFloatOrNull() ?: def

    private fun printAttendee(a: Attendee, markAsPrinted: Boolean) {
        if (printing) return
        printing = true
        b.btnPrint.isEnabled = false
        b.btnPrint.text = "Imprimiendo…"
        lifecycleScope.launch {
            try {
                if (!printer.isConnected) {
                    if (savedPrinterAddress() == null) throw IllegalStateException("Primero conecte la impresora")
                    if (!hasBtPermissions()) throw IllegalStateException("Faltan permisos de Bluetooth")
                    printer.connect(savedPrinterAddress()!!, prefs.getString("printer_name", "") ?: "",
                        prefs.getString("protocol", "auto") ?: "auto")
                }
                val cfg = labelConfig()
                val reverse = prefs.getBoolean("reverse_bits", false) xor printer.msbFirst
                val rows = withContext(Dispatchers.Default) {
                    LabelRenderer.toRows(LabelRenderer.renderForPrinter(a, cfg), reverse, cfg.headDots)
                }
                val before = (num("offset_mm", 0f) * LabelRenderer.DOTS_PER_MM).toInt().coerceAtLeast(0)
                val after = (num("gap_mm", 3f) * LabelRenderer.DOTS_PER_MM).toInt().coerceAtLeast(0)
                val density = prefs.getString("density", "2")?.toIntOrNull() ?: 2
                printer.print(
                    rows, before, after, density,
                    labelSense = prefs.getBoolean("label_sense", false),
                    // Tamaño físico: ancho a lo largo del cabezal × largo en el avance del papel
                    labelSizeMm = if (cfg.rotation == 90 || cfg.rotation == 270) cfg.heightMm to cfg.widthMm else cfg.widthMm to cfg.heightMm,
                    gapMm = num("gap_mm", 3f),
                )
                if (markAsPrinted) {
                    val t = store.markPrinted(a)
                    sync.enqueue(a, t)
                    launch { sync.flush(); updateCounter() }
                }
                updateCounter()
                if (current == a) setStatus("✓ Etiqueta impresa", COLOR_OK)
                if (markAsPrinted && b.swContinuous.isChecked) {
                    delay(1200)
                    startScan()
                }
            } catch (e: Exception) {
                setStatus("Error al imprimir", COLOR_ERROR)
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("No se pudo imprimir")
                    .setMessage(e.message ?: e.toString())
                    .setPositiveButton("Reintentar") { _, _ -> printAttendee(a, markAsPrinted) }
                    .setNegativeButton("Cerrar", null)
                    .show()
            } finally {
                printing = false
                b.btnPrint.isEnabled = true
                b.btnPrint.text = "IMPRIMIR"
            }
        }
    }

    // ---------------- Bluetooth ----------------

    private fun btAdapter(): BluetoothAdapter? =
        (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter

    private fun requiredPerms(): Array<String> =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    private fun hasBtPermissions() = requiredPerms().all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun withBluetooth(action: () -> Unit) {
        val adapter = btAdapter()
        if (adapter == null) {
            toast("Este teléfono no tiene Bluetooth")
            return
        }
        if (!hasBtPermissions()) {
            afterPermissions = { withBluetooth(action) }
            permLauncher.launch(requiredPerms())
            return
        }
        if (!adapter.isEnabled) {
            afterPermissions = { if (btAdapter()?.isEnabled == true) action() else toast("Encienda el Bluetooth") }
            enableBtLauncher.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
            return
        }
        action()
    }

    private fun savedPrinterAddress(): String? = prefs.getString("printer_address", null)

    private fun onConnectClicked() {
        when {
            printer.isConnected -> AlertDialog.Builder(this)
                .setTitle(printer.deviceName)
                .setItems(arrayOf("Desconectar", "Elegir otra impresora")) { _, which ->
                    printer.disconnect()
                    if (which == 1) withBluetooth { scanForPrinters() }
                }.show()
            printer.state == PrinterManager.State.CONNECTING -> {}
            savedPrinterAddress() != null -> AlertDialog.Builder(this)
                .setTitle("Impresora")
                .setItems(arrayOf("Reconectar a ${prefs.getString("printer_name", "impresora guardada")}", "Buscar impresoras")) { _, which ->
                    if (which == 0) withBluetooth { connectSaved(silent = false) } else withBluetooth { scanForPrinters() }
                }.show()
            else -> withBluetooth { scanForPrinters() }
        }
    }

    private fun connectSaved(silent: Boolean) {
        val addr = savedPrinterAddress() ?: return
        val name = prefs.getString("printer_name", "") ?: ""
        connectTo(addr, name, silent)
    }

    private fun connectTo(address: String, name: String, silent: Boolean) {
        lifecycleScope.launch {
            try {
                printer.connect(address, name, prefs.getString("protocol", "auto") ?: "auto")
                prefs.edit().putString("printer_address", address).putString("printer_name", printer.deviceName).apply()
                if (!silent) toast("Impresora conectada")
            } catch (e: Exception) {
                if (!silent) toast(e.message ?: "No se pudo conectar")
            }
            updatePrinterUi()
        }
    }

    private fun updatePrinterUi() {
        when (printer.state) {
            PrinterManager.State.CONNECTED -> {
                b.txtPrinter.text = "● ${printer.deviceName} conectada\nprotocolo ${printer.protocolLabel()}"
                b.txtPrinter.setTextColor(COLOR_OK)
                b.btnConnect.text = "Opciones"
            }
            PrinterManager.State.CONNECTING -> {
                b.txtPrinter.text = "Conectando a ${printer.deviceName}…"
                b.txtPrinter.setTextColor(Color.DKGRAY)
                b.btnConnect.text = "…"
            }
            PrinterManager.State.DISCONNECTED -> {
                val saved = prefs.getString("printer_name", null)
                b.txtPrinter.text = if (saved != null) "○ $saved (desconectada)" else "Impresora no conectada"
                b.txtPrinter.setTextColor(Color.DKGRAY)
                b.btnConnect.text = "Conectar"
            }
        }
    }

    private data class Found(val address: String, val name: String, var rssi: Int, val paired: Boolean = false)

    private fun scanForPrinters() {
        val scanner = btAdapter()?.bluetoothLeScanner
        if (scanner == null) {
            toast("No se puede buscar dispositivos Bluetooth")
            return
        }
        val found = LinkedHashMap<String, Found>()
        val items = mutableListOf<Found>()
        val adapter = object : ArrayAdapter<Found>(this, android.R.layout.simple_list_item_2, android.R.id.text1, items) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = convertView ?: layoutInflater.inflate(android.R.layout.simple_list_item_2, parent, false)
                val f = items[position]
                v.findViewById<TextView>(android.R.id.text1).text = f.name
                v.findViewById<TextView>(android.R.id.text2).text =
                    if (f.paired && f.rssi == 0) "${f.address}  ·  emparejada" else "${f.address}  ·  señal ${f.rssi} dBm"
                return v
            }
        }
        // Impresoras ya emparejadas (las de Bluetooth clásico no aparecen en la búsqueda BLE)
        try {
            btAdapter()?.bondedDevices?.forEach { d ->
                val n = d.name ?: return@forEach
                found[d.address] = Found(d.address, n, 0, paired = true)
            }
        } catch (_: Exception) {}
        items.addAll(found.values.sortedByDescending { PrinterManager.looksLikePrinter(it.name) })
        val callback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val name = result.scanRecord?.deviceName ?: result.device.name ?: return
                val addr = result.device.address
                runOnUiThread {
                    val f = found[addr]
                    if (f == null) found[addr] = Found(addr, name, result.rssi, paired = result.device.bondState == BluetoothDevice.BOND_BONDED)
                    else f.rssi = result.rssi
                    items.clear()
                    items.addAll(found.values.sortedWith(
                        compareByDescending<Found> { PrinterManager.looksLikePrinter(it.name) }.thenByDescending { it.rssi }
                    ))
                    adapter.notifyDataSetChanged()
                }
            }
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Buscando impresoras…")
            .setAdapter(adapter) { _, which ->
                val f = items[which]
                try { scanner.stopScan(callback) } catch (_: Exception) {}
                connectTo(f.address, f.name, silent = false)
            }
            .setNeutralButton("Escribir dirección") { _, _ ->
                try { scanner.stopScan(callback) } catch (_: Exception) {}
                askPrinterAddress()
            }
            .setNegativeButton("Cancelar", null)
            .create()
        dialog.setOnDismissListener { try { scanner.stopScan(callback) } catch (_: Exception) {} }
        dialog.show()
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
        scanner.startScan(null, settings, callback)
        lifecycleScope.launch {
            delay(15_000)
            try { scanner.stopScan(callback) } catch (_: Exception) {}
            if (dialog.isShowing) {
                dialog.setTitle(if (items.isEmpty()) "No se encontraron dispositivos" else "Elija la impresora")
            }
        }
    }

    /** Conexión directa escribiendo la dirección Bluetooth (aparece en la hoja de autoprueba). */
    private fun askPrinterAddress() {
        val input = EditText(this).apply {
            hint = "Ej.: 66:32:30:57:FA:D6"
            isSingleLine = true
            setText(prefs.getString("printer_address", "") ?: "")
        }
        val box = LinearLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(input, LinearLayout.LayoutParams(-1, -2)) }
        AlertDialog.Builder(this)
            .setTitle("Dirección Bluetooth de la impresora")
            .setView(box)
            .setPositiveButton("Conectar") { _, _ ->
                val raw = input.text.toString().trim().uppercase().replace('-', ':')
                val addr = if (Regex("^[0-9A-F]{12}$").matches(raw)) raw.chunked(2).joinToString(":") else raw
                if (!BluetoothAdapter.checkBluetoothAddress(addr)) {
                    toast("Dirección no válida")
                } else {
                    val name = try { btAdapter()?.getRemoteDevice(addr)?.name } catch (_: Exception) { null }
                    connectTo(addr, name ?: "Impresora $addr", silent = false)
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ---------------- Utilidades ----------------

    private fun time(t: Long) = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(t))
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    companion object {
        private val COLOR_OK = Color.parseColor("#2E7D32")
        private val COLOR_WARN = Color.parseColor("#E65100")
        private val COLOR_ERROR = Color.parseColor("#C62828")
        private val COLOR_INFO = Color.parseColor("#1F4E79")
    }
}
