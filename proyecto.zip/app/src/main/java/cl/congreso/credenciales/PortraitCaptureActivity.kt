package cl.congreso.credenciales

import com.journeyapps.barcodescanner.CaptureActivity

/** Lector de QR fijo en vertical. */
class PortraitCaptureActivity : CaptureActivity()
