package cl.congreso.credenciales

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothSocket
import android.bluetooth.BluetoothStatusCodes
import android.content.Context
import android.os.Build
import android.util.Log
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import java.io.ByteArrayOutputStream
import java.util.UUID

/**
 * Impresoras térmicas BLE genéricas de la familia "cat printer" (app Fun Print / iPrint).
 *
 * Protocolo clásico (MX05, MX06, MX08, MX10, GB01, GT01…):
 *   paquete = 51 78 CMD 00 LEN 00 DATOS CRC8 FF, todo por la característica AE01.
 * Protocolo MXW01:
 *   control = 22 21 CMD 00 LEN_L LEN_H DATOS CRC8 FF por AE01, imagen por AE03.
 *
 * Impresoras genéricas ("BlueTooth Printer", Xprinter, etc.):
 *   ESC/POS (imagen con GS v 0) o TSPL (etiquetas), por Bluetooth clásico (SPP)
 *   o, si no hay SPP, por la característica BLE escribible que expongan.
 */
@SuppressLint("MissingPermission")
class PrinterManager(private val ctx: Context) {

    enum class Protocol { CLASSIC, MXW01, ESCPOS, TSPL }
    enum class State { DISCONNECTED, CONNECTING, CONNECTED }

    var onStateChanged: ((State, String) -> Unit)? = null

    var state = State.DISCONNECTED
        private set
    var deviceName: String = ""
        private set
    var deviceAddress: String = ""
        private set
    var protocol = Protocol.CLASSIC
        private set

    private var gatt: BluetoothGatt? = null
    @Volatile private var spp: BluetoothSocket? = null

    /** Ritmo de envío por BLE a impresoras genéricas: "fast", "normal" o "slow". */
    var bleSpeed: String = "normal"
    private var ctrlChar: BluetoothGattCharacteristic? = null
    private var dataChar: BluetoothGattCharacteristic? = null
    private var notifyChar: BluetoothGattCharacteristic? = null
    private var chunkSize = 20

    private var connectDone: CompletableDeferred<Boolean>? = null
    private var servicesDone: CompletableDeferred<Boolean>? = null
    private var mtuDone: CompletableDeferred<Int>? = null
    private var descDone: CompletableDeferred<Boolean>? = null
    @Volatile private var writeDone: CompletableDeferred<Boolean>? = null
    @Volatile private var paused = false
    private val notifications = Channel<ByteArray>(Channel.UNLIMITED)
    private val lock = Mutex()
    private val log = ArrayDeque<String>()
    private var charsInfo = ""

    private fun logEvent(msg: String) {
        Log.d(TAG, msg)
        synchronized(log) {
            val t = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
            log.addLast("$t $msg")
            while (log.size > 40) log.removeFirst()
        }
    }

    /** Texto con información técnica para diagnosticar problemas de impresión. */
    fun diagnostics(): String {
        val sb = StringBuilder()
        sb.append("Dispositivo: $deviceName ($deviceAddress)\n")
        sb.append("Estado: $state · Protocolo: ${protocolLabel()} · Bloque: $chunkSize bytes\n\n")
        sb.append("Características:\n").append(charsInfo.ifBlank { "(sin datos)" }).append("\n\n")
        sb.append("Eventos:\n")
        synchronized(log) { log.forEach { sb.append(it).append('\n') } }
        return sb.toString()
    }

    fun protocolLabel(): String {
        val name = when (protocol) {
            Protocol.CLASSIC -> "clásico"
            Protocol.MXW01 -> "MXW01"
            Protocol.ESCPOS -> "ESC/POS"
            Protocol.TSPL -> "TSPL"
        }
        val link = when {
            spp != null -> " · Bluetooth clásico"
            protocol == Protocol.ESCPOS || protocol == Protocol.TSPL -> " · BLE"
            else -> ""
        }
        return name + link
    }

    /** ESC/POS y TSPL esperan el punto de la izquierda en el bit más alto de cada byte. */
    val msbFirst get() = protocol == Protocol.ESCPOS || protocol == Protocol.TSPL

    private fun setState(s: State, msg: String) {
        state = s
        onStateChanged?.invoke(s, msg)
    }

    private val callback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            logEvent("conexión status=$status estado=$newState")
            if (newState == BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                connectDone?.complete(true)
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED || status != BluetoothGatt.GATT_SUCCESS) {
                connectDone?.complete(false)
                servicesDone?.complete(false)
                writeDone?.complete(false)
                descDone?.complete(false)
                try { g.close() } catch (_: Exception) {}
                if (gatt == g) gatt = null
                setState(State.DISCONNECTED, "Impresora desconectada")
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            servicesDone?.complete(status == BluetoothGatt.GATT_SUCCESS)
        }

        override fun onMtuChanged(g: BluetoothGatt, mtu: Int, status: Int) {
            mtuDone?.complete(if (status == BluetoothGatt.GATT_SUCCESS) mtu else 23)
        }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
            descDone?.complete(status == BluetoothGatt.GATT_SUCCESS)
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            writeDone?.complete(status == BluetoothGatt.GATT_SUCCESS)
        }

        @Deprecated("API < 33")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            @Suppress("DEPRECATION")
            handleNotify(c.value ?: return)
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) {
            handleNotify(value)
        }
    }

    private fun handleNotify(v: ByteArray) {
        logEvent("← " + v.take(16).joinToString(" ") { "%02X".format(it) })
        // Control de flujo del protocolo clásico: 51 78 AE 00 01 00 {10|00} ...
        if (v.size >= 7 && v[0] == 0x51.toByte() && v[1] == 0x78.toByte() && v[2] == 0xAE.toByte()) {
            paused = v[6] == 0x10.toByte()
        }
        // Impresoras genéricas: XOFF (13) pide pausar el envío, XON (11) reanudarlo
        if (protocol == Protocol.ESCPOS || protocol == Protocol.TSPL) {
            for (b in v) {
                if (b == 0x13.toByte()) paused = true
                if (b == 0x11.toByte()) paused = false
            }
        }
        notifications.trySend(v)
    }

    // ------------------------------------------------------------------
    // Conexión
    // ------------------------------------------------------------------

    suspend fun connect(address: String, name: String, forced: String = "auto") = lock.withLock {
        disconnectInternal()
        val adapter = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
            ?: throw IllegalStateException("Este teléfono no tiene Bluetooth")
        if (!adapter.isEnabled) throw IllegalStateException("Bluetooth está apagado")
        val device = adapter.getRemoteDevice(address)
        deviceName = name.ifBlank { device.name ?: address }
        deviceAddress = address
        setState(State.CONNECTING, "Conectando a $deviceName…")

        // Impresoras genéricas: primero Bluetooth clásico (SPP)
        val type = try { device.type } catch (_: Exception) { BluetoothDevice.DEVICE_TYPE_UNKNOWN }
        val generic = when (forced) {
            "escpos", "tspl" -> true
            "classic", "mxw01" -> false
            else -> !looksLikeCatPrinter(deviceName) &&
                (looksLikeGenericPrinter(deviceName) || type == BluetoothDevice.DEVICE_TYPE_CLASSIC || type == BluetoothDevice.DEVICE_TYPE_DUAL)
        }
        val genericProtocol = if (forced == "tspl") Protocol.TSPL else Protocol.ESCPOS
        logEvent("conectando $deviceName tipo=$type genérica=$generic")
        // Bluetooth clásico solo si ya está emparejada en Android: si no, Android intenta
        // emparejar por su cuenta y muestra "clave incorrecta". BLE no necesita emparejar.
        val bonded = try { device.bondState == BluetoothDevice.BOND_BONDED } catch (_: Exception) { false }
        if (generic && type != BluetoothDevice.DEVICE_TYPE_LE && !bonded) logEvent("no emparejada: se usa BLE")
        if (generic && type != BluetoothDevice.DEVICE_TYPE_LE && bonded) {
            val s = connectSpp(device)
            if (s != null) {
                spp = s
                protocol = genericProtocol
                chunkSize = 512
                charsInfo = "Bluetooth clásico (SPP)"
                logEvent("conectada por SPP, protocolo=${protocolLabel()}")
                setState(State.CONNECTED, "$deviceName conectada")
                return@withLock
            }
            if (type == BluetoothDevice.DEVICE_TYPE_CLASSIC) {
                setState(State.DISCONNECTED, "No se pudo conectar")
                throw IllegalStateException("No se pudo conectar con la impresora. Revise que esté encendida y emparejada en Ajustes de Android → Bluetooth (clave habitual 0000 o 1234).")
            }
            logEvent("SPP no disponible, se intenta BLE")
        }

        var ok = false
        for (attempt in 1..3) {
            connectDone = CompletableDeferred()
            val g = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                device.connectGatt(ctx, false, callback, BluetoothDevice.TRANSPORT_LE)
            else device.connectGatt(ctx, false, callback)
            gatt = g
            ok = withTimeoutOrNull(12_000) { connectDone!!.await() } ?: false
            if (ok) break
            try { g.disconnect(); g.close() } catch (_: Exception) {}
            gatt = null
            delay(600)
        }
        if (!ok) {
            setState(State.DISCONNECTED, "No se pudo conectar")
            throw IllegalStateException(
                if (generic) "No se pudo conectar con la impresora. Emparéjela primero en Ajustes de Android → Bluetooth (clave habitual 0000 o 1234) y vuelva a intentar."
                else "No se pudo conectar con la impresora"
            )
        }
        val g = gatt!!
        delay(300)

        mtuDone = CompletableDeferred()
        val mtu = if (g.requestMtu(200)) withTimeoutOrNull(3_000) { mtuDone!!.await() } ?: 23 else 23
        chunkSize = (mtu - 3).coerceIn(20, 180)

        servicesDone = CompletableDeferred()
        g.discoverServices()
        if (withTimeoutOrNull(10_000) { servicesDone!!.await() } != true) {
            disconnectInternal()
            throw IllegalStateException("La impresora no respondió al descubrir servicios")
        }

        val chars = g.services.flatMap { it.characteristics }
        fun byShort(s: Int) = chars.firstOrNull { it.uuid == uuid16(s) }
        charsInfo = g.services.joinToString("\n") { sv ->
            "servicio " + sv.uuid.toString().substring(4, 8) + ": " + sv.characteristics.joinToString(", ") { ch ->
                ch.uuid.toString().substring(4, 8) + "[" + props(ch.properties) + "]"
            }
        }
        ctrlChar = byShort(0xAE01)
        notifyChar = byShort(0xAE02)
        dataChar = byShort(0xAE03)

        // Impresora genérica por BLE (o sin las características de la familia MX)
        if (generic || (ctrlChar == null && forced == "auto")) {
            val writable = chars.filter {
                it.properties and (BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE or BluetoothGattCharacteristic.PROPERTY_WRITE) != 0
            }
            ctrlChar = GENERIC_WRITE_UUIDS.firstNotNullOfOrNull { u -> writable.firstOrNull { it.uuid == u } } ?: writable.firstOrNull()
            if (ctrlChar == null) {
                disconnectInternal()
                throw IllegalStateException("Este dispositivo no parece ser una impresora compatible")
            }
            dataChar = null
            protocol = genericProtocol
            // Canal de avisos del mismo servicio (p. ej. 2AF0), usado para el control de flujo
            val svc = ctrlChar!!.service
            notifyChar = svc?.characteristics?.firstOrNull {
                it.properties and (BluetoothGattCharacteristic.PROPERTY_NOTIFY or BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0
            }
            paused = false
            notifyChar?.let { enableNotify(g, it) }
            while (notifications.tryReceive().isSuccess) { /* vaciar */ }
            logEvent("conectada por BLE, MTU=$mtu, escritura=${ctrlChar!!.uuid.toString().substring(0, 8)}, protocolo=${protocolLabel()}")
            setState(State.CONNECTED, "$deviceName conectada")
            return@withLock
        }

        if (ctrlChar == null) {
            // Algunas variantes usan otros UUID: toma la primera característica escribible
            ctrlChar = chars.firstOrNull {
                it.properties and (BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE or BluetoothGattCharacteristic.PROPERTY_WRITE) != 0
            }
            notifyChar = notifyChar ?: chars.firstOrNull { it.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0 }
        }
        if (ctrlChar == null) {
            disconnectInternal()
            throw IllegalStateException("Este dispositivo no parece ser una impresora compatible")
        }

        protocol = when (forced) {
            "classic" -> Protocol.CLASSIC
            "mxw01" -> Protocol.MXW01
            // Las MX05/MX06/MX10 también exponen AE03, así que solo el nombre identifica a la MXW01
            else -> if (deviceName.uppercase().startsWith("MXW")) Protocol.MXW01 else Protocol.CLASSIC
        }
        logEvent("conectada, MTU=$mtu, protocolo=${protocolLabel()}")
        if (protocol == Protocol.MXW01 && dataChar == null) dataChar = ctrlChar

        notifyChar?.let { enableNotify(g, it) }
        while (notifications.tryReceive().isSuccess) { /* vaciar */ }
        paused = false

        setState(State.CONNECTED, "$deviceName conectada")
    }

    private suspend fun enableNotify(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
        g.setCharacteristicNotification(c, true)
        val d = c.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")) ?: return
        descDone = CompletableDeferred()
        val value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
        val started = if (Build.VERSION.SDK_INT >= 33) {
            g.writeDescriptor(d, value) == BluetoothStatusCodes.SUCCESS
        } else {
            @Suppress("DEPRECATION")
            d.value = value
            @Suppress("DEPRECATION")
            g.writeDescriptor(d)
        }
        if (started) withTimeoutOrNull(3_000) { descDone!!.await() }
    }

    /** Abre un canal Bluetooth clásico (puerto serie). Devuelve null si la impresora no lo acepta. */
    private suspend fun connectSpp(device: BluetoothDevice): BluetoothSocket? = withContext(Dispatchers.IO) {
        try {
            (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter?.cancelDiscovery()
        } catch (_: Exception) {}
        val makers: List<Pair<String, () -> BluetoothSocket>> = listOf(
            "seguro" to { device.createRfcommSocketToServiceRecord(SPP_UUID) },
            "inseguro" to { device.createInsecureRfcommSocketToServiceRecord(SPP_UUID) },
            "canal 1" to {
                device.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                    .invoke(device, 1) as BluetoothSocket
            },
        )
        for ((label, make) in makers) {
            var s: BluetoothSocket? = null
            try {
                val sock = make()
                s = sock
                // connect() bloquea: si no responde, se cierra el socket para cortarlo
                val timer = launch { delay(12_000); try { sock.close() } catch (_: Exception) {} }
                try {
                    sock.connect()
                } finally {
                    timer.cancel()
                }
                logEvent("SPP $label: conectado")
                return@withContext sock
            } catch (e: Exception) {
                logEvent("SPP $label: ${e.message ?: e.javaClass.simpleName}")
                try { s?.close() } catch (_: Exception) {}
            }
        }
        null
    }

    fun disconnect() {
        disconnectInternal()
        setState(State.DISCONNECTED, "Impresora desconectada")
    }

    private fun disconnectInternal() {
        spp?.let { s ->
            spp = null
            try { s.close() } catch (_: Exception) {}
        }
        state = State.DISCONNECTED
        val g = gatt ?: return
        gatt = null
        try { g.disconnect() } catch (_: Exception) {}
        try { g.close() } catch (_: Exception) {}
    }

    val isConnected get() = state == State.CONNECTED && (gatt != null || spp != null)

    // ------------------------------------------------------------------
    // Escritura
    // ------------------------------------------------------------------

    private suspend fun writeChunk(c: BluetoothGattCharacteristic, data: ByteArray, noResponse: Boolean) {
        val g = gatt ?: throw IllegalStateException("Impresora desconectada")
        var waited = 0
        while (paused && waited < 10_000) { delay(20); waited += 20 }
        val canNoResp = c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0
        val type = if (noResponse && canNoResp) BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
        else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT

        for (attempt in 0 until 100) {
            val d = CompletableDeferred<Boolean>()
            writeDone = d
            val started = if (Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(c, data, type) == BluetoothStatusCodes.SUCCESS
            } else {
                @Suppress("DEPRECATION")
                c.writeType = type
                @Suppress("DEPRECATION")
                c.value = data
                @Suppress("DEPRECATION")
                g.writeCharacteristic(c)
            }
            if (started) {
                withTimeoutOrNull(1_500) { d.await() }
                return
            }
            if (gatt == null) throw IllegalStateException("Impresora desconectada")
            delay(10)
        }
        logEvent("escritura rechazada")
        throw IllegalStateException("La impresora no acepta datos")
    }

    private suspend fun writeStream(c: BluetoothGattCharacteristic, data: ByteArray, pauseMs: Long) {
        var i = 0
        while (i < data.size) {
            val end = minOf(i + chunkSize, data.size)
            writeChunk(c, data.copyOfRange(i, end), noResponse = true)
            if (pauseMs > 0) delay(pauseMs)
            i = end
        }
    }

    // ------------------------------------------------------------------
    // Impresión
    // ------------------------------------------------------------------

    /**
     * @param rows filas de 48 bytes
     * @param feedBeforeDots avance previo en puntos (8 puntos = 1 mm)
     * @param feedAfterDots avance posterior en puntos
     * @param density 1..4
     */
    suspend fun print(
        rows: List<ByteArray>, feedBeforeDots: Int, feedAfterDots: Int, density: Int,
        labelSense: Boolean = false, labelSizeMm: Pair<Float, Float>? = null, gapMm: Float = 3f,
    ) = lock.withLock {
        if (!isConnected) throw IllegalStateException("Impresora desconectada")
        logEvent("imprimir ${rows.size} filas, protocolo=${protocolLabel()}, densidad=$density")
        when (protocol) {
            Protocol.CLASSIC -> printClassic(rows, feedBeforeDots, feedAfterDots, density)
            Protocol.MXW01 -> printMxw01(rows, feedBeforeDots, feedAfterDots, density)
            Protocol.ESCPOS -> printEscPos(rows, feedBeforeDots, feedAfterDots, labelSense)
            Protocol.TSPL -> printTspl(rows, density, labelSizeMm, gapMm)
        }
    }

    // ---------------- Impresoras genéricas ----------------

    /** Envía bytes por SPP o por BLE, en bloques pequeños para no desbordar el búfer. */
    private suspend fun sendRaw(data: ByteArray) {
        val s = spp
        if (s != null) {
            try {
                withContext(Dispatchers.IO) {
                    val os = s.outputStream
                    var i = 0
                    while (i < data.size) {
                        val end = minOf(i + 256, data.size)
                        os.write(data, i, end - i)
                        os.flush()
                        delay(12)
                        i = end
                    }
                }
            } catch (e: Exception) {
                logEvent("error SPP: ${e.message}")
                disconnectInternal()
                setState(State.DISCONNECTED, "Impresora desconectada")
                throw IllegalStateException("Se perdió la conexión con la impresora")
            }
        } else {
            val c = ctrlChar ?: throw IllegalStateException("Impresora desconectada")
            val canAck = c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE != 0
            // fast: bloques grandes sin confirmación · normal: 100 bytes confirmados · slow: 20 bytes confirmados
            val (size, ack, pause) = when (bleSpeed) {
                "fast" -> Triple(chunkSize, false, 15L)
                "slow" -> Triple(20, canAck, 15L)
                else -> Triple(minOf(chunkSize, 100), canAck, 8L)
            }
            var i = 0
            while (i < data.size) {
                val end = minOf(i + size, data.size)
                writeChunk(c, data.copyOfRange(i, end), noResponse = !ack)
                if (pause > 0) delay(pause)
                i = end
            }
        }
        logEvent("enviados ${data.size} bytes")
    }

    /** Prueba mínima: imprime texto sin imagen, para comprobar que la impresora recibe datos. */
    suspend fun printTestText() = lock.withLock {
        if (!isConnected) throw IllegalStateException("Impresora desconectada")
        logEvent("prueba de texto, protocolo=${protocolLabel()}")
        when (protocol) {
            Protocol.ESCPOS -> {
                val out = ByteArrayOutputStream()
                out.write(byteArrayOf(0x1B, 0x40))
                out.write(byteArrayOf(0x1D, 0x21, 0x11))              // doble alto y ancho
                out.write("PRUEBA\n".toByteArray(Charsets.US_ASCII))
                out.write(byteArrayOf(0x1D, 0x21, 0x00))
                out.write("Credenciales Congreso\nESC/POS OK\n".toByteArray(Charsets.US_ASCII))
                escFeed(out, 120)
                sendRaw(out.toByteArray())
            }
            Protocol.TSPL -> sendRaw(("SIZE 48 mm,30 mm\r\nGAP 3 mm,0 mm\r\nDIRECTION 0\r\nCLS\r\n" +
                "TEXT 20,30,\"3\",0,1,1,\"PRUEBA\"\r\nTEXT 20,90,\"2\",0,1,1,\"TSPL OK\"\r\nPRINT 1,1\r\n")
                .toByteArray(Charsets.US_ASCII))
            else -> throw IllegalStateException("La prueba de texto es solo para impresoras ESC/POS o TSPL")
        }
        delay(300)
    }

    private fun escFeed(out: ByteArrayOutputStream, dots: Int) {
        var left = dots
        while (left > 0) {
            val n = minOf(left, 255)
            out.write(byteArrayOf(0x1B, 0x4A, n.toByte()))   // ESC J n
            left -= n
        }
    }

    private suspend fun printEscPos(rows: List<ByteArray>, before: Int, after: Int, labelSense: Boolean) {
        val bpr = rows.firstOrNull()?.size ?: 48
        val head = ByteArrayOutputStream()
        head.write(byteArrayOf(0x1B, 0x40))                   // ESC @ (reinicio)
        head.write(byteArrayOf(0x1B, 0x61, 0x00))             // alineación izquierda
        escFeed(head, before)
        sendRaw(head.toByteArray())
        delay(100)
        // Filas en blanco se avanzan con ESC J; el resto en franjas de hasta 48 filas (GS v 0)
        var y = 0
        var total = 0
        while (y < rows.size) {
            val out = ByteArrayOutputStream()
            var blank = 0
            while (y < rows.size && rows[y].all { it.toInt() == 0 }) { blank++; y++ }
            if (y >= rows.size) { escFeed(out, blank); sendRaw(out.toByteArray()); break }
            escFeed(out, blank)
            var n = 0
            while (y + n < rows.size && n < 48 && !rows[y + n].all { it.toInt() == 0 }) n++
            out.write(byteArrayOf(0x1D, 0x76, 0x30, 0x00,
                (bpr and 0xFF).toByte(), ((bpr shr 8) and 0xFF).toByte(),
                (n and 0xFF).toByte(), ((n shr 8) and 0xFF).toByte()))
            for (i in y until y + n) out.write(rows[i])
            y += n
            total += out.size()
            sendRaw(out.toByteArray())
            if (spp == null) delay(40)
        }
        val tail = ByteArrayOutputStream()
        if (labelSense) tail.write(byteArrayOf(0x1D, 0x0C))  // GS FF: avanza hasta la siguiente etiqueta
        else escFeed(tail, after)
        sendRaw(tail.toByteArray())
        logEvent("imagen enviada: $total bytes")
        delay(300)
    }

    private suspend fun printTspl(rows: List<ByteArray>, density: Int, sizeMm: Pair<Float, Float>?, gapMm: Float) {
        val bpr = rows.firstOrNull()?.size ?: 48
        val h = rows.size
        val wMm = sizeMm?.first ?: (bpr * 8 / DOTS_PER_MM)
        val hMm = sizeMm?.second ?: (h / DOTS_PER_MM)
        val dens = when (density) { 1 -> 5; 3 -> 12; 4 -> 15; else -> 8 }
        fun f(v: Float) = String.format(java.util.Locale.US, "%.1f", v)
        val out = ByteArrayOutputStream()
        out.write(("SIZE ${f(wMm)} mm,${f(hMm)} mm\r\nGAP ${f(gapMm)} mm,0 mm\r\nDENSITY $dens\r\n" +
            "DIRECTION 0\r\nREFERENCE 0,0\r\nCLS\r\nBITMAP 0,0,$bpr,$h,0,").toByteArray(Charsets.US_ASCII))
        // En TSPL el bit en 0 imprime negro
        for (r in rows) out.write(ByteArray(r.size) { (r[it].toInt() xor 0xFF).toByte() })
        out.write("\r\nPRINT 1,1\r\n".toByteArray(Charsets.US_ASCII))
        sendRaw(out.toByteArray())
        delay(300)
    }

    private suspend fun printClassic(rows: List<ByteArray>, before: Int, after: Int, density: Int) {
        val c = ctrlChar!!
        val energy = when (density) { 1 -> 0x2000; 3 -> 0x6000; 4 -> 0xFFFF; else -> 0x4000 }
        val out = ByteArrayOutputStream()
        fun cmd(command: Int, vararg data: Int) = out.write(classicPacket(command, ByteArray(data.size) { data[it].toByte() }))

        cmd(0xA3, 0x00)                                          // estado
        cmd(0xA4, 0x33)                                          // calidad
        cmd(0xAF, energy and 0xFF, (energy shr 8) and 0xFF)     // energía
        cmd(0xBE, 0x01)                                          // aplicar energía
        cmd(0xBD, 0x23)                                          // velocidad
        cmd(0xA6, 0xAA, 0x55, 0x17, 0x38, 0x44, 0x5F, 0x5F, 0x5F, 0x44, 0x38, 0x2C) // inicio
        feedClassic(out, before)
        var blank = 0
        for (r in rows) {
            if (r.all { it.toInt() == 0 }) { blank++; continue }
            if (blank > 0) { feedClassic(out, blank); blank = 0 }
            out.write(classicPacket(0xA2, r))
        }
        feedClassic(out, blank + after)
        cmd(0xA6, 0xAA, 0x55, 0x17, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x17) // fin
        cmd(0xA3, 0x00)

        val bytes = out.toByteArray()
        writeStream(c, bytes, if (chunkSize <= 20) 3 else 8)
        logEvent("enviados ${bytes.size} bytes")
        delay(500)
    }

    private fun feedClassic(out: ByteArrayOutputStream, dots: Int) {
        var left = dots
        while (left > 0) {
            val n = minOf(left, 255)
            out.write(classicPacket(0xA1, byteArrayOf(n.toByte(), 0)))
            left -= n
        }
    }

    private suspend fun printMxw01(rows: List<ByteArray>, before: Int, after: Int, density: Int) {
        val c = ctrlChar!!
        val d = dataChar!!
        val intensity = when (density) { 1 -> 0x40; 3 -> 0x90; 4 -> 0xC0; else -> 0x68 }

        val all = ArrayList<ByteArray>()
        repeat(before) { all.add(ByteArray(48)) }
        all.addAll(rows)
        repeat(after) { all.add(ByteArray(48)) }
        while (all.size < 90) all.add(ByteArray(48))
        val lines = all.size

        while (notifications.tryReceive().isSuccess) { }
        writeChunk(c, mxwPacket(0xA2, byteArrayOf(intensity.toByte())), noResponse = false)
        writeChunk(c, mxwPacket(0xA1, byteArrayOf(0)), noResponse = false)
        waitNotify(0xA1, 2_000)
        writeChunk(c, mxwPacket(0xA9, byteArrayOf((lines and 0xFF).toByte(), ((lines shr 8) and 0xFF).toByte(), 0x30, 0x00)), noResponse = false)
        waitNotify(0xA9, 3_000)

        val img = ByteArrayOutputStream()
        all.forEach { img.write(it) }
        writeStream(d, img.toByteArray(), if (chunkSize <= 20) 4 else 10)

        writeChunk(c, mxwPacket(0xAD, byteArrayOf(0)), noResponse = false)
        waitNotify(0xAA, 30_000)
    }

    private suspend fun waitNotify(cmd: Int, timeoutMs: Long): ByteArray? = withTimeoutOrNull(timeoutMs) {
        var found: ByteArray? = null
        while (found == null) {
            val v = notifications.receive()
            if (v.size >= 3 && (v[2].toInt() and 0xFF) == cmd) found = v
        }
        found
    }

    companion object {
        private const val TAG = "Printer"
        private const val DOTS_PER_MM = 8f
        private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb")

        /** Características BLE de escritura habituales en impresoras ESC/POS genéricas. */
        private val GENERIC_WRITE_UUIDS = listOf(
            "00002af1-0000-1000-8000-00805f9b34fb",
            "49535343-8841-43f4-a8d4-ecbe34729bb3",
            "bef8d6c9-9c21-4c9e-b632-bd58c1009f9f",
            "0000ff02-0000-1000-8000-00805f9b34fb",
            "0000ffe1-0000-1000-8000-00805f9b34fb",
        ).map { UUID.fromString(it) }

        fun looksLikeCatPrinter(name: String?): Boolean =
            name != null && Regex("^(MXW?\\d|GB\\d|GT\\d|YT\\d|LY\\d|Cat|Mini|Paperang|Peripage)", RegexOption.IGNORE_CASE)
                .containsMatchIn(name.trim())

        fun looksLikeGenericPrinter(name: String?): Boolean =
            name != null && Regex("(blue ?tooth printer|printer|pos|xp-|mpt|rpp|pt-?2|^bt)", RegexOption.IGNORE_CASE)
                .containsMatchIn(name.trim())

        fun props(p: Int): String {
            val out = mutableListOf<String>()
            if (p and BluetoothGattCharacteristic.PROPERTY_READ != 0) out.add("R")
            if (p and BluetoothGattCharacteristic.PROPERTY_WRITE != 0) out.add("W")
            if (p and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0) out.add("Wnr")
            if (p and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) out.add("N")
            if (p and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0) out.add("I")
            return out.joinToString("/")
        }

        fun uuid16(s: Int): UUID = UUID.fromString("0000%04x-0000-1000-8000-00805f9b34fb".format(s))

        private val CRC_TABLE = IntArray(256).also { t ->
            for (i in 0 until 256) {
                var crc = i
                repeat(8) { crc = if (crc and 0x80 != 0) ((crc shl 1) xor 0x07) and 0xFF else (crc shl 1) and 0xFF }
                t[i] = crc
            }
        }

        fun crc8(data: ByteArray): Int {
            var crc = 0
            for (b in data) crc = CRC_TABLE[(crc xor (b.toInt() and 0xFF)) and 0xFF]
            return crc
        }

        fun classicPacket(cmd: Int, data: ByteArray): ByteArray {
            val out = ByteArrayOutputStream()
            out.write(0x51); out.write(0x78); out.write(cmd); out.write(0x00)
            out.write(data.size and 0xFF); out.write(0x00)
            out.write(data)
            out.write(crc8(data)); out.write(0xFF)
            return out.toByteArray()
        }

        fun mxwPacket(cmd: Int, data: ByteArray): ByteArray {
            val out = ByteArrayOutputStream()
            out.write(0x22); out.write(0x21); out.write(cmd); out.write(0x00)
            out.write(data.size and 0xFF); out.write((data.size shr 8) and 0xFF)
            out.write(data)
            out.write(crc8(data)); out.write(0xFF)
            return out.toByteArray()
        }

        /** Nombres habituales de estas impresoras, para ordenarlas primero en la lista. */
        fun looksLikePrinter(name: String?): Boolean {
            if (name == null) return false
            return Regex("^(MX|GB|GT|YT|X\\d|MXW|LY|AI|BQ|JX|C\\d|PT|P\\d|Mini|Cat|Print|Paperang|Peripage)", RegexOption.IGNORE_CASE)
                .containsMatchIn(name.trim()) || looksLikeGenericPrinter(name)
        }
    }
}
