package cl.congreso.credenciales

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothStatusCodes
import android.content.Context
import android.os.Build
import android.util.Log
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import java.io.ByteArrayOutputStream
import java.util.UUID

/**
 * Impresoras térmicas BLE genéricas de la familia "cat printer" (app Fun Print / iPrint).
 *
 * Protocolo clásico (MX05, MX06, MX08, MX10, GB01, GT01…):
 *   paquete = 51 78 CMD 00 LEN 00 DATOS CRC8 FF, todo por la característica AE01.
 * Protocolo MXW01:
 *   control = 22 21 CMD 00 LEN_L LEN_H DATOS CRC8 FF por AE01, imagen por AE03.
 */
@SuppressLint("MissingPermission")
class PrinterManager(private val ctx: Context) {

    enum class Protocol { CLASSIC, MXW01 }
    enum class State { DISCONNECTED, CONNECTING, CONNECTED }

    var onStateChanged: ((State, String) -> Unit)? = null

    var state = State.DISCONNECTED
        private set
    var deviceName: String = ""
        private set
    var deviceAddress: String = ""
        private set
    var protocol = Protocol.CLASSIC
        private set

    private var gatt: BluetoothGatt? = null
    private var ctrlChar: BluetoothGattCharacteristic? = null
    private var dataChar: BluetoothGattCharacteristic? = null
    private var notifyChar: BluetoothGattCharacteristic? = null
    private var chunkSize = 20

    private var connectDone: CompletableDeferred<Boolean>? = null
    private var servicesDone: CompletableDeferred<Boolean>? = null
    private var mtuDone: CompletableDeferred<Int>? = null
    private var descDone: CompletableDeferred<Boolean>? = null
    @Volatile private var writeDone: CompletableDeferred<Boolean>? = null
    @Volatile private var paused = false
    private val notifications = Channel<ByteArray>(Channel.UNLIMITED)
    private val lock = Mutex()

    private fun setState(s: State, msg: String) {
        state = s
        onStateChanged?.invoke(s, msg)
    }

    private val callback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            Log.d(TAG, "state status=$status new=$newState")
            if (newState == BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                connectDone?.complete(true)
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED || status != BluetoothGatt.GATT_SUCCESS) {
                connectDone?.complete(false)
                servicesDone?.complete(false)
                writeDone?.complete(false)
                descDone?.complete(false)
                try { g.close() } catch (_: Exception) {}
                if (gatt == g) gatt = null
                setState(State.DISCONNECTED, "Impresora desconectada")
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            servicesDone?.complete(status == BluetoothGatt.GATT_SUCCESS)
        }

        override fun onMtuChanged(g: BluetoothGatt, mtu: Int, status: Int) {
            mtuDone?.complete(if (status == BluetoothGatt.GATT_SUCCESS) mtu else 23)
        }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
            descDone?.complete(status == BluetoothGatt.GATT_SUCCESS)
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            writeDone?.complete(status == BluetoothGatt.GATT_SUCCESS)
        }

        @Deprecated("API < 33")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            @Suppress("DEPRECATION")
            handleNotify(c.value ?: return)
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) {
            handleNotify(value)
        }
    }

    private fun handleNotify(v: ByteArray) {
        Log.d(TAG, "notify " + v.joinToString(" ") { "%02X".format(it) })
        // Control de flujo del protocolo clásico: 51 78 AE 00 01 00 {10|00} ...
        if (v.size >= 7 && v[0] == 0x51.toByte() && v[1] == 0x78.toByte() && v[2] == 0xAE.toByte()) {
            paused = v[6] == 0x10.toByte()
        }
        notifications.trySend(v)
    }

    // ------------------------------------------------------------------
    // Conexión
    // ------------------------------------------------------------------

    suspend fun connect(address: String, name: String, forced: String = "auto") = lock.withLock {
        disconnectInternal()
        val adapter = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
            ?: throw IllegalStateException("Este teléfono no tiene Bluetooth")
        if (!adapter.isEnabled) throw IllegalStateException("Bluetooth está apagado")
        val device = adapter.getRemoteDevice(address)
        deviceName = name.ifBlank { device.name ?: address }
        deviceAddress = address
        setState(State.CONNECTING, "Conectando a $deviceName…")

        var ok = false
        for (attempt in 1..3) {
            connectDone = CompletableDeferred()
            val g = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                device.connectGatt(ctx, false, callback, BluetoothDevice.TRANSPORT_LE)
            else device.connectGatt(ctx, false, callback)
            gatt = g
            ok = withTimeoutOrNull(12_000) { connectDone!!.await() } ?: false
            if (ok) break
            try { g.disconnect(); g.close() } catch (_: Exception) {}
            gatt = null
            delay(600)
        }
        if (!ok) {
            setState(State.DISCONNECTED, "No se pudo conectar")
            throw IllegalStateException("No se pudo conectar con la impresora")
        }
        val g = gatt!!
        delay(300)

        mtuDone = CompletableDeferred()
        val mtu = if (g.requestMtu(200)) withTimeoutOrNull(3_000) { mtuDone!!.await() } ?: 23 else 23
        chunkSize = (mtu - 3).coerceIn(20, 180)

        servicesDone = CompletableDeferred()
        g.discoverServices()
        if (withTimeoutOrNull(10_000) { servicesDone!!.await() } != true) {
            disconnectInternal()
            throw IllegalStateException("La impresora no respondió al descubrir servicios")
        }

        val chars = g.services.flatMap { it.characteristics }
        fun byShort(s: Int) = chars.firstOrNull { it.uuid == uuid16(s) }
        ctrlChar = byShort(0xAE01)
        notifyChar = byShort(0xAE02)
        dataChar = byShort(0xAE03)
        if (ctrlChar == null) {
            // Algunas variantes usan otros UUID: toma la primera característica escribible
            ctrlChar = chars.firstOrNull {
                it.properties and (BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE or BluetoothGattCharacteristic.PROPERTY_WRITE) != 0
            }
            notifyChar = notifyChar ?: chars.firstOrNull { it.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0 }
        }
        if (ctrlChar == null) {
            disconnectInternal()
            throw IllegalStateException("Este dispositivo no parece ser una impresora compatible")
        }

        protocol = when (forced) {
            "classic" -> Protocol.CLASSIC
            "mxw01" -> Protocol.MXW01
            else -> if (dataChar != null || deviceName.uppercase().startsWith("MXW")) Protocol.MXW01 else Protocol.CLASSIC
        }
        if (protocol == Protocol.MXW01 && dataChar == null) dataChar = ctrlChar

        notifyChar?.let { enableNotify(g, it) }
        while (notifications.tryReceive().isSuccess) { /* vaciar */ }
        paused = false

        setState(State.CONNECTED, "$deviceName conectada")
    }

    private suspend fun enableNotify(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
        g.setCharacteristicNotification(c, true)
        val d = c.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")) ?: return
        descDone = CompletableDeferred()
        val value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
        val started = if (Build.VERSION.SDK_INT >= 33) {
            g.writeDescriptor(d, value) == BluetoothStatusCodes.SUCCESS
        } else {
            @Suppress("DEPRECATION")
            d.value = value
            @Suppress("DEPRECATION")
            g.writeDescriptor(d)
        }
        if (started) withTimeoutOrNull(3_000) { descDone!!.await() }
    }

    fun disconnect() {
        disconnectInternal()
        setState(State.DISCONNECTED, "Impresora desconectada")
    }

    private fun disconnectInternal() {
        val g = gatt ?: return
        gatt = null
        try { g.disconnect() } catch (_: Exception) {}
        try { g.close() } catch (_: Exception) {}
        state = State.DISCONNECTED
    }

    val isConnected get() = state == State.CONNECTED && gatt != null

    // ------------------------------------------------------------------
    // Escritura
    // ------------------------------------------------------------------

    private suspend fun writeChunk(c: BluetoothGattCharacteristic, data: ByteArray, noResponse: Boolean) {
        val g = gatt ?: throw IllegalStateException("Impresora desconectada")
        var waited = 0
        while (paused && waited < 10_000) { delay(20); waited += 20 }
        val canNoResp = c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0
        val type = if (noResponse && canNoResp) BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
        else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT

        for (attempt in 0 until 100) {
            val d = CompletableDeferred<Boolean>()
            writeDone = d
            val started = if (Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(c, data, type) == BluetoothStatusCodes.SUCCESS
            } else {
                @Suppress("DEPRECATION")
                c.writeType = type
                @Suppress("DEPRECATION")
                c.value = data
                @Suppress("DEPRECATION")
                g.writeCharacteristic(c)
            }
            if (started) {
                withTimeoutOrNull(1_500) { d.await() }
                return
            }
            if (gatt == null) throw IllegalStateException("Impresora desconectada")
            delay(10)
        }
        throw IllegalStateException("La impresora no acepta datos")
    }

    private suspend fun writeStream(c: BluetoothGattCharacteristic, data: ByteArray, pauseMs: Long) {
        var i = 0
        while (i < data.size) {
            val end = minOf(i + chunkSize, data.size)
            writeChunk(c, data.copyOfRange(i, end), noResponse = true)
            if (pauseMs > 0) delay(pauseMs)
            i = end
        }
    }

    // ------------------------------------------------------------------
    // Impresión
    // ------------------------------------------------------------------

    /**
     * @param rows filas de 48 bytes
     * @param feedBeforeDots avance previo en puntos (8 puntos = 1 mm)
     * @param feedAfterDots avance posterior en puntos
     * @param density 1..4
     */
    suspend fun print(rows: List<ByteArray>, feedBeforeDots: Int, feedAfterDots: Int, density: Int) = lock.withLock {
        if (!isConnected) throw IllegalStateException("Impresora desconectada")
        when (protocol) {
            Protocol.CLASSIC -> printClassic(rows, feedBeforeDots, feedAfterDots, density)
            Protocol.MXW01 -> printMxw01(rows, feedBeforeDots, feedAfterDots, density)
        }
    }

    private suspend fun printClassic(rows: List<ByteArray>, before: Int, after: Int, density: Int) {
        val c = ctrlChar!!
        val energy = when (density) { 1 -> 0x2000; 3 -> 0x6000; 4 -> 0xFFFF; else -> 0x4000 }
        val out = ByteArrayOutputStream()
        fun cmd(command: Int, vararg data: Int) = out.write(classicPacket(command, ByteArray(data.size) { data[it].toByte() }))

        cmd(0xA3, 0x00)                                          // estado
        cmd(0xA4, 0x33)                                          // calidad
        cmd(0xAF, energy and 0xFF, (energy shr 8) and 0xFF)     // energía
        cmd(0xBE, 0x01)                                          // aplicar energía
        cmd(0xBD, 0x23)                                          // velocidad
        cmd(0xA6, 0xAA, 0x55, 0x17, 0x38, 0x44, 0x5F, 0x5F, 0x5F, 0x44, 0x38, 0x2C) // inicio
        feedClassic(out, before)
        var blank = 0
        for (r in rows) {
            if (r.all { it.toInt() == 0 }) { blank++; continue }
            if (blank > 0) { feedClassic(out, blank); blank = 0 }
            out.write(classicPacket(0xA2, r))
        }
        feedClassic(out, blank + after)
        cmd(0xA6, 0xAA, 0x55, 0x17, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x17) // fin
        cmd(0xA3, 0x00)

        writeStream(c, out.toByteArray(), if (chunkSize <= 20) 3 else 8)
        delay(500)
    }

    private fun feedClassic(out: ByteArrayOutputStream, dots: Int) {
        var left = dots
        while (left > 0) {
            val n = minOf(left, 255)
            out.write(classicPacket(0xA1, byteArrayOf(n.toByte(), 0)))
            left -= n
        }
    }

    private suspend fun printMxw01(rows: List<ByteArray>, before: Int, after: Int, density: Int) {
        val c = ctrlChar!!
        val d = dataChar!!
        val intensity = when (density) { 1 -> 0x40; 3 -> 0x90; 4 -> 0xC0; else -> 0x68 }

        val all = ArrayList<ByteArray>()
        repeat(before) { all.add(ByteArray(48)) }
        all.addAll(rows)
        repeat(after) { all.add(ByteArray(48)) }
        while (all.size < 90) all.add(ByteArray(48))
        val lines = all.size

        while (notifications.tryReceive().isSuccess) { }
        writeChunk(c, mxwPacket(0xA2, byteArrayOf(intensity.toByte())), noResponse = false)
        writeChunk(c, mxwPacket(0xA1, byteArrayOf(0)), noResponse = false)
        waitNotify(0xA1, 2_000)
        writeChunk(c, mxwPacket(0xA9, byteArrayOf((lines and 0xFF).toByte(), ((lines shr 8) and 0xFF).toByte(), 0x30, 0x00)), noResponse = false)
        waitNotify(0xA9, 3_000)

        val img = ByteArrayOutputStream()
        all.forEach { img.write(it) }
        writeStream(d, img.toByteArray(), if (chunkSize <= 20) 4 else 10)

        writeChunk(c, mxwPacket(0xAD, byteArrayOf(0)), noResponse = false)
        waitNotify(0xAA, 30_000)
    }

    private suspend fun waitNotify(cmd: Int, timeoutMs: Long): ByteArray? = withTimeoutOrNull(timeoutMs) {
        var found: ByteArray? = null
        while (found == null) {
            val v = notifications.receive()
            if (v.size >= 3 && (v[2].toInt() and 0xFF) == cmd) found = v
        }
        found
    }

    companion object {
        private const val TAG = "Printer"

        fun uuid16(s: Int): UUID = UUID.fromString("0000%04x-0000-1000-8000-00805f9b34fb".format(s))

        private val CRC_TABLE = IntArray(256).also { t ->
            for (i in 0 until 256) {
                var crc = i
                repeat(8) { crc = if (crc and 0x80 != 0) ((crc shl 1) xor 0x07) and 0xFF else (crc shl 1) and 0xFF }
                t[i] = crc
            }
        }

        fun crc8(data: ByteArray): Int {
            var crc = 0
            for (b in data) crc = CRC_TABLE[(crc xor (b.toInt() and 0xFF)) and 0xFF]
            return crc
        }

        fun classicPacket(cmd: Int, data: ByteArray): ByteArray {
            val out = ByteArrayOutputStream()
            out.write(0x51); out.write(0x78); out.write(cmd); out.write(0x00)
            out.write(data.size and 0xFF); out.write(0x00)
            out.write(data)
            out.write(crc8(data)); out.write(0xFF)
            return out.toByteArray()
        }

        fun mxwPacket(cmd: Int, data: ByteArray): ByteArray {
            val out = ByteArrayOutputStream()
            out.write(0x22); out.write(0x21); out.write(cmd); out.write(0x00)
            out.write(data.size and 0xFF); out.write((data.size shr 8) and 0xFF)
            out.write(data)
            out.write(crc8(data)); out.write(0xFF)
            return out.toByteArray()
        }

        /** Nombres habituales de estas impresoras, para ordenarlas primero en la lista. */
        fun looksLikePrinter(name: String?): Boolean {
            if (name == null) return false
            return Regex("^(MX|GB|GT|YT|X\\d|MXW|LY|AI|BQ|JX|C\\d|PT|P\\d|Mini|Cat|Print|Paperang|Peripage)", RegexOption.IGNORE_CASE)
                .containsMatchIn(name.trim())
        }
    }
}
