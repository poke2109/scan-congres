package cl.congreso.credenciales

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Registro compartido de impresiones entre varios teléfonos, usando una
 * planilla de Google publicada como aplicación web (Apps Script).
 * Si no hay conexión, las impresiones quedan en cola y se suben después.
 */
class SyncManager(ctx: Context, private val prefs: SharedPreferences) {

    data class Rec(val id: String, val device: String, val time: Long)
    private data class Pending(val id: String, val name: String, val inst: String, val device: String, val time: Long)

    private val pendingFile = File(ctx.filesDir, "pendientes.json")
    private val pending = mutableListOf<Pending>()
    private val mutex = Mutex()

    @Volatile private var remote: Map<String, List<Rec>> = emptyMap()
    @Volatile var lastOk: Long = 0L
        private set
    @Volatile var lastError: String? = null
        private set

    val url: String get() = prefs.getString("sync_url", "")?.trim().orEmpty()
    val enabled: Boolean get() = url.startsWith("https://")
    val deviceName: String
        get() = prefs.getString("device_name", null)?.trim()?.takeIf { it.isNotEmpty() } ?: Build.MODEL

    init {
        try {
            if (pendingFile.exists()) {
                val arr = JSONArray(pendingFile.readText())
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    pending.add(Pending(o.getString("id"), o.optString("name"), o.optString("inst"), o.optString("device"), o.getLong("t")))
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun savePending() {
        val arr = JSONArray()
        synchronized(pending) {
            pending.forEach {
                arr.put(JSONObject().put("id", it.id).put("name", it.name).put("inst", it.inst).put("device", it.device).put("t", it.time))
            }
        }
        pendingFile.writeText(arr.toString())
    }

    fun pendingCount() = synchronized(pending) { pending.size }

    /** Impresiones registradas en la planilla (de todos los teléfonos) para este pedido. */
    fun recordsFor(id: String): List<Rec> = remote[AttendeeStore.normId(id)] ?: emptyList()

    fun remoteUniqueCount(): Int = remote.size

    fun enqueue(a: Attendee, time: Long) {
        if (!enabled || a.id == AttendeeStore.MANUAL_ID || a.id.isBlank()) return
        synchronized(pending) { pending.add(Pending(a.id, a.name, a.institution, deviceName, time)) }
        savePending()
        // Se refleja de inmediato en la caché local
        val key = AttendeeStore.normId(a.id)
        val m = remote.toMutableMap()
        m[key] = (m[key] ?: emptyList()) + Rec(a.id, deviceName, time)
        remote = m
    }

    /** Descarga el registro completo. Devuelve true si hubo conexión. */
    suspend fun refresh(timeoutMs: Int = 8000): Boolean = withContext(Dispatchers.IO) {
        if (!enabled) return@withContext false
        try {
            val body = httpGet("$url?action=list", timeoutMs)
            val o = JSONObject(body)
            val arr = o.getJSONArray("items")
            val m = HashMap<String, MutableList<Rec>>()
            for (i in 0 until arr.length()) {
                val r = arr.getJSONObject(i)
                val id = r.optString("id")
                if (id.isBlank()) continue
                m.getOrPut(AttendeeStore.normId(id)) { mutableListOf() }
                    .add(Rec(id, r.optString("device"), r.optLong("t")))
            }
            // Mantiene visibles las impresiones propias que aún no se suben
            synchronized(pending) {
                pending.forEach { p ->
                    val list = m.getOrPut(AttendeeStore.normId(p.id)) { mutableListOf() }
                    if (list.none { it.time == p.time }) list.add(Rec(p.id, p.device, p.time))
                }
            }
            remote = m
            lastOk = System.currentTimeMillis()
            lastError = null
            true
        } catch (e: Exception) {
            lastError = e.message ?: e.javaClass.simpleName
            false
        }
    }

    /** Sube las impresiones pendientes. */
    suspend fun flush(): Boolean = mutex.withLock {
        withContext(Dispatchers.IO) {
            if (!enabled) return@withContext false
            while (true) {
                val p = synchronized(pending) { pending.firstOrNull() } ?: break
                try {
                    val q = listOf(
                        "action" to "add", "id" to p.id, "name" to p.name, "inst" to p.inst,
                        "device" to p.device, "t" to p.time.toString(),
                    ).joinToString("&") { (k, v) -> k + "=" + URLEncoder.encode(v, "UTF-8") }
                    val body = httpGet("$url?$q", 10_000)
                    if (!JSONObject(body).optBoolean("ok")) throw IllegalStateException("respuesta inválida")
                    synchronized(pending) { pending.remove(p) }
                    savePending()
                    lastOk = System.currentTimeMillis()
                    lastError = null
                } catch (e: Exception) {
                    lastError = e.message ?: e.javaClass.simpleName
                    return@withContext false
                }
            }
            true
        }
    }

    private fun httpGet(address: String, timeoutMs: Int): String {
        var target = address
        repeat(6) {
            val c = URL(target).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            c.requestMethod = "GET"
            try {
                val code = c.responseCode
                if (code in 300..399) {
                    target = c.getHeaderField("Location") ?: throw IllegalStateException("redirección sin destino")
                    return@repeat
                }
                if (code != 200) throw IllegalStateException("HTTP $code")
                val text = c.inputStream.bufferedReader().use { it.readText() }
                if (!text.trimStart().startsWith("{")) {
                    throw IllegalStateException("La planilla no respondió con datos (revise que esté publicada para \"Cualquier persona\")")
                }
                return text
            } finally {
                c.disconnect()
            }
        }
        throw IllegalStateException("Demasiadas redirecciones")
    }
}
