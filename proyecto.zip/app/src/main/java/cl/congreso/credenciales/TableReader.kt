package cl.congreso.credenciales

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.util.zip.ZipInputStream

/**
 * Lee planillas CSV o XLSX y devuelve filas de texto.
 * No usa librerías externas: el XLSX se lee directamente desde su XML interno.
 */
object TableReader {

    fun read(bytes: ByteArray, fileName: String): List<List<String>> {
        val isZip = bytes.size > 4 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()
        val rows = if (isZip) readXlsx(bytes) else readCsv(bytes)
        return rows
            .map { r -> r.map { it.trim() } }
            .filter { r -> r.any { it.isNotEmpty() } }
    }

    // ---------------- CSV ----------------

    private fun decode(bytes: ByteArray): String {
        var b = bytes
        if (b.size >= 3 && b[0] == 0xEF.toByte() && b[1] == 0xBB.toByte() && b[2] == 0xBF.toByte()) {
            b = b.copyOfRange(3, b.size)
        }
        return try {
            Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(b)).toString()
        } catch (e: CharacterCodingException) {
            String(b, Charset.forName("windows-1252"))
        }
    }

    private fun readCsv(bytes: ByteArray): List<List<String>> {
        val text = decode(bytes)
        val firstLine = text.lineSequence().firstOrNull { it.isNotBlank() } ?: return emptyList()
        val delimiter = listOf(';', ',', '\t', '|').maxBy { d -> firstLine.count { it == d } }

        val rows = mutableListOf<List<String>>()
        var row = mutableListOf<String>()
        val field = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < text.length) {
            val c = text[i]
            if (inQuotes) {
                if (c == '"') {
                    if (i + 1 < text.length && text[i + 1] == '"') {
                        field.append('"'); i++
                    } else inQuotes = false
                } else field.append(c)
            } else {
                when (c) {
                    '"' -> inQuotes = true
                    delimiter -> { row.add(field.toString()); field.clear() }
                    '\r' -> {}
                    '\n' -> {
                        row.add(field.toString()); field.clear()
                        rows.add(row); row = mutableListOf()
                    }
                    else -> field.append(c)
                }
            }
            i++
        }
        if (field.isNotEmpty() || row.isNotEmpty()) {
            row.add(field.toString()); rows.add(row)
        }
        return rows
    }

    // ---------------- XLSX ----------------

    private fun readXlsx(bytes: ByteArray): List<List<String>> {
        val entries = HashMap<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            var e = zip.nextEntry
            while (e != null) {
                val n = e.name.trimStart('/')
                if (n == "xl/sharedStrings.xml" || n == "xl/workbook.xml" ||
                    n == "xl/_rels/workbook.xml.rels" || n.startsWith("xl/worksheets/sheet")
                ) {
                    entries[n] = zip.readBytes()
                }
                e = zip.nextEntry
            }
        }
        val shared = entries["xl/sharedStrings.xml"]?.let { parseSharedStrings(it) } ?: emptyList()
        val sheetPath = firstSheetPath(entries)
            ?: entries.keys.filter { it.startsWith("xl/worksheets/sheet") }.minOrNull()
            ?: return emptyList()
        val sheet = entries[sheetPath] ?: return emptyList()
        return parseSheet(sheet, shared)
    }

    private fun firstSheetPath(entries: Map<String, ByteArray>): String? {
        val wb = entries["xl/workbook.xml"] ?: return null
        val rels = entries["xl/_rels/workbook.xml.rels"] ?: return null
        var rid: String? = null
        val p = Xml.newPullParser()
        p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        p.setInput(ByteArrayInputStream(wb), null)
        while (p.next() != XmlPullParser.END_DOCUMENT) {
            if (p.eventType == XmlPullParser.START_TAG && p.name == "sheet") {
                rid = p.getAttributeValue(null, "r:id")
                break
            }
        }
        if (rid == null) return null
        val r = Xml.newPullParser()
        r.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        r.setInput(ByteArrayInputStream(rels), null)
        while (r.next() != XmlPullParser.END_DOCUMENT) {
            if (r.eventType == XmlPullParser.START_TAG && r.name == "Relationship" &&
                r.getAttributeValue(null, "Id") == rid
            ) {
                val target = r.getAttributeValue(null, "Target") ?: return null
                return if (target.startsWith("/")) target.trimStart('/') else "xl/$target"
            }
        }
        return null
    }

    private fun parseSharedStrings(data: ByteArray): List<String> {
        val out = mutableListOf<String>()
        val p = Xml.newPullParser()
        p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        p.setInput(ByteArrayInputStream(data), null)
        val sb = StringBuilder()
        var inSi = false
        var inT = false
        var inRph = false
        while (p.next() != XmlPullParser.END_DOCUMENT) {
            when (p.eventType) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "si" -> { inSi = true; sb.clear() }
                    "t" -> inT = true
                    "rPh" -> inRph = true
                }
                XmlPullParser.TEXT -> if (inSi && inT && !inRph) sb.append(p.text)
                XmlPullParser.END_TAG -> when (p.name) {
                    "si" -> { out.add(sb.toString()); inSi = false }
                    "t" -> inT = false
                    "rPh" -> inRph = false
                }
            }
        }
        return out
    }

    private fun colIndex(ref: String?): Int {
        if (ref == null) return -1
        var n = 0
        for (ch in ref) {
            if (ch in 'A'..'Z') n = n * 26 + (ch - 'A' + 1) else break
        }
        return n - 1
    }

    private fun parseSheet(data: ByteArray, shared: List<String>): List<List<String>> {
        val rows = mutableListOf<List<String>>()
        val p = Xml.newPullParser()
        p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        p.setInput(ByteArrayInputStream(data), null)
        var current: MutableList<String>? = null
        var cellType: String? = null
        var cellCol = -1
        val value = StringBuilder()
        var inValue = false
        while (p.next() != XmlPullParser.END_DOCUMENT) {
            when (p.eventType) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "row" -> current = mutableListOf()
                    "c" -> {
                        cellType = p.getAttributeValue(null, "t")
                        val idx = colIndex(p.getAttributeValue(null, "r"))
                        cellCol = if (idx >= 0) idx else (current?.size ?: 0)
                        value.clear()
                    }
                    "v", "t" -> inValue = true
                }
                XmlPullParser.TEXT -> if (inValue) value.append(p.text)
                XmlPullParser.END_TAG -> when (p.name) {
                    "v", "t" -> inValue = false
                    "c" -> {
                        val row = current ?: continue
                        var text = value.toString()
                        if (cellType == "s") {
                            text = text.trim().toIntOrNull()?.let { shared.getOrNull(it) } ?: ""
                        } else if (cellType == null || cellType == "n") {
                            text = normalizeNumber(text)
                        }
                        while (row.size < cellCol) row.add("")
                        if (row.size == cellCol) row.add(text) else if (cellCol < row.size) row[cellCol] = text
                    }
                    "row" -> { current?.let { rows.add(it) }; current = null }
                }
            }
        }
        return rows
    }

    private fun normalizeNumber(s: String): String {
        val t = s.trim()
        val d = t.toDoubleOrNull() ?: return t
        return if (d == Math.floor(d) && Math.abs(d) < 1e15) d.toLong().toString() else t
    }
}
